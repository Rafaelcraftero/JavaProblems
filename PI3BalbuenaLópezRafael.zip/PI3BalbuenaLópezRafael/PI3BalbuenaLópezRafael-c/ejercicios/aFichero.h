#include <stdio.h>
#include <stdlib.h>

#ifndef AFICHERO_H_
#define AFICHERO_H_

void solucionAFichero(char* fileEnd, char* cadena);


#endif /* AFICHERO_H_ */
