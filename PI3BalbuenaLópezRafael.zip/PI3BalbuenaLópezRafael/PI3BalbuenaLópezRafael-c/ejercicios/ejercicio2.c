#include "ejercicio2.h"

void testEj2(){
	char mem[1024]="";
	char mem2[1024]="";
	char aux[10000]="";
	char* fileInit="ficheros/PI3Ej2DatosEntrada.txt";
	list ls=file_to_list_of_list(fileInit);
	list k=list_empty(list_type);
	list kls=list_empty(list_type);
	for(int i=0;i<ls.size;i++){
		snprintf(aux, sizeof aux,"%sLista de entrada: %s\n", aux,list_tostring((list*)list_get(&ls, i), mem));
		kls=*(list*)list_get(&ls, i);
		int*res=(int*)list_get(&kls, kls.size-1);
		int position=0;
		int longitud=kls.size-1;
		solucionRecEj2(kls, 0, longitud, res,&k, &position);

		snprintf(aux, sizeof aux, "%sSecuencia de suma mayor en intervalo [%d, %d): \nSubsecuencia = %s; Suma obtenida = %d\n===============================================================\n",
				aux,position,position+k.size,list_tostring(&k, mem2),*res);
//		kls2=list_empty(list_type);
	}
	printf("%s",aux);
	solucionAFichero ("ficheros/PI3Ej2Resultados.txt", aux);
}

void solucionRecEj2(list ls, int a, int b, int*res, list*lres, int*position){
	if(a<b){
		list k=list_empty(list_type);
		k =list_sublist(&ls, a, b);
		int aux=sumList(k);
		if( b>0 && a<ls.size-1){
			if(*res<=aux){
				*position=a;
				*res=aux;
				*lres=list_sublist(&ls, a, b);
			}
			if(b>a+1){
				solucionRecEj2(ls, a, b-1, res, lres, position);
			}
			if(*res<=aux){
				*position=a;
				*lres=list_sublist(&ls, a, b);
				*res=aux;

			}
			solucionRecEj2(ls, a+1,ls.size-1, res, lres, position);
		}
	}
}

int sumList(list ls){
	int i=0, acum=0;
	for(i=0;i<ls.size;i++){
		acum+=*(int*)list_get(&ls, i);

	}
	return acum;
}
