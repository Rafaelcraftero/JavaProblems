#include "ejercicio4.h"

void testEj4(){
	char * tokens[2];
	char aux[10000];
	int i=0;
	char buffer[10000]="";
	list ls=list_of_string_of_file("ficheros/PI3Ej4DatosEntrada.txt");
	snprintf(buffer, sizeof buffer, "Pares de entrada:\n");
	while(i<ls.size){
		snprintf(aux, sizeof aux, "%s",list_get_string(&ls,i,aux));
		split_text((char*)aux, ",", tokens);
		int a=int_parse_s(tokens[0]);
		int b=int_parse_s(tokens[1]);
		double resNoMem=solucionRecNoMemEj4(a,b);
		double resMem=solucionRecConMemEj4(a,b);
		double resIter=solucionIterEj4(a,b);
		snprintf(buffer, sizeof buffer, "%s(a,b) = (%d, %d)\n",buffer,a,b);
		snprintf(buffer, sizeof buffer, "%sF. Recursiva sin memoria: %.0lf\nF. Recursiva con memoria: %.0lf\nF. Iterativa:		  %.0lf\n===============================================================\n",
				buffer,resNoMem,resMem,resIter);
		i++;
	}
	printf("%s",buffer);
	solucionAFichero("ficheros/PI2Ej3Resultados.txt",buffer);
}

double solucionIterEj4(int a, int b){
	double res=0;
	int i=0, j=0;

	list ls=list_empty(int_pair_type);
	list lsH=list_empty(int_pair_type);
	list lsRes=list_empty(int_pair_type);

	if(a<2 && b<2){
		return a+(b*b);

	}else if(a<2 || b<2){
		return (a*a)+b;

	}
	int_pair p1={a/2,b-1};
	int_pair p2={a/3,b-2};
	int_pair p3={a-2,b/4};

	if((p1.a<2 && p1.b<2) || (p1.a<2 || p1.b<2)){
		list_add(&lsRes, &p1);
	}else{
		list_add(&ls, &p1);
	}

	if((p2.a<2 && p2.b<2) || (p2.a<2 || p2.b<2)){
		list_add(&lsRes, &p2);
	}else{
		list_add(&ls, &p2);
	}

	if((p3.a<2 && p3.b<2) || (p3.a<2 || p3.b<2)){
		list_add(&lsRes, &p3);
	}else{
		list_add(&ls, &p3);
	}

	while(ls.size!=0){
		int_pair pl=*(int_pair*)list_get(&ls, 0);

		p1.a=pl.a/2;
		p1.b=pl.b-1;

		p2.a=pl.a/3;
		p2.b=pl.b-2;

		p3.a=pl.a-2;
		p3.b=pl.b/4;

		if((p1.a<2 && p1.b<2) || (p1.a<2 || p1.b<2)){
			list_add(&lsRes, &p1);
		}else{
			list_add(&ls, &p1);
		}

		if((p2.a<2 && p2.b<2) || (p2.a<2 || p2.b<2)){
			list_add(&lsRes, &p2);
		}else{
			list_add(&ls, &p2);
		}

		if((p3.a<2 && p3.b<2) || (p3.a<2 || p3.b<2)){
			list_add(&lsRes, &p3);
		}else{
			list_add(&ls, &p3);
		}

		for(i=1;i<ls.size;i++){
			list_add(&lsH, (int_pair*)list_get(&ls, i));
		}
		ls=list_empty(int_pair_type);
		for(j=0;j<lsH.size;j++){
			list_add(&ls, list_get(&lsH, j));
		}
			lsH=list_empty(int_pair_type);
		if(ls.size<1){
			break;
		}
	}
	i=0;
	while(i<lsRes.size){
		int_pair plr=*(int_pair*)list_get(&lsRes, i);
		  if(plr.a<2 && plr.b<2){
			  res=res+ plr.a+(plr.b*plr.b);
		  }else if(plr.a<2 || plr.b<2){
			  res=res+(plr.a*plr.a)+plr.b;
		  }
		  i++;
	}

	return res;
}

double solucionRecNoMemEj4(int a, int b){

	if(a<2 && b<2){
		return a+(b*b);

	}else if(a<2 || b<2){
		return (a*a)+b;

	}else{

		return solucionRecNoMemEj4(a/2, b-1)+solucionRecNoMemEj4(a/3, b-2)
				+solucionRecNoMemEj4(a-2, b/4);
	}

	return -1;
}

double solucionRecConMemEj4(int a, int b){
	  double buffer[10000];
	  int n3=0;
	  if(!(a<2 && b<2) && !(a<2 || b<2) ){
		  n3++;
		  buffer[n3] = solucionRecNoMemEj4(a/2, b-1)+solucionRecNoMemEj4(a/3, b-2)
							+solucionRecNoMemEj4(a-2, b/4);
	  	  return buffer[n3];
	  }
	  if(a<2 && b<2){
		  return a+(b*b);
	  }else if(a<2 || b<2){
		  return (a*a)+b;
	  }
	return -1;
}




