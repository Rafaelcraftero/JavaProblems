#include "ejercicio1.h"

int exception=0;


void testEj1(){
	char res1[60000]="";
	char res2[10000]="";
	char res3[10000]="";
	char res4[10000]="";
	char res5[10000]="";
	char res6[10000]="";
	aCadena("ficheros/PI3Ej1DatosEntrada1.txt", res1);
	aCadena("ficheros/PI3Ej1DatosEntrada2.txt", res2);
	aCadena("ficheros/PI3Ej1DatosEntrada3.txt", res3);
	aCadena("ficheros/PI3Ej1DatosEntrada4.txt", res4);
	aCadena("ficheros/PI3Ej1DatosEntrada5.txt", res5);
	aCadena("ficheros/PI3Ej1DatosEntrada6.txt", res6);

	strcat(res1, res2);
	strcat(res1, res3);
	strcat(res1, res4);
	strcat(res1, res5);
	strcat(res1, res6);
	printf("%s",res1);
	solucionAFichero ("ficheros/PI3Ej1Resultados.txt", res1);
}

void aCadena(char* fileInit, char Ret[10000]){
	matrix r=leeEjercicio1(file_to_list_of_list(fileInit));
	int i, j;
	char buffer[10000]="";
	char aux[10000]="";
	char*res="true";
	solucionRecEj1(r);
	if(exception!=0){
		res="false";
		exception=0;
	}
	if(r.nf<=32){
		for (i = 0; i < r.nf; i++) {
			for (j = 0; j < r.nc; j++){
				snprintf(buffer, sizeof buffer, "%s%d ", buffer,matrix_get(r,i,j));
			}
			snprintf(buffer, sizeof buffer, "%s\n", buffer);
		}
		snprintf(aux, sizeof aux, "Matriz de entrada (%d*%d):\n%s\nEs matriz valida? %s\n================================================================\n",
				r.nf,r.nc,buffer,res);
	}else{
		snprintf(buffer, sizeof buffer, "%s. No se muestra dado el tamaño\n", buffer);
		snprintf(aux, sizeof aux, "Matriz de entrada (%d*%d)%s\nEs matriz valida? %s\n================================================================\n",
				r.nf,r.nc,buffer,res);
	}

	strcpy(Ret,aux);

}

matrix leeEjercicio1(list listas){
	int i=0, i2=0;
	int res[listas.size][listas.size];
	list Aux = list_empty(int_type);
	while(i<listas.size){
		i2=0;
		Aux = *(list*)list_get(&listas,i);
		while(i2<Aux.size){
			res[i][i2]=*(int*)list_get(&Aux,i2);
			i2++;
		}
		i++;

	}
	matrix r= matrix_of_array(*res,listas.size,listas.size);
	char buffer[10000]="";
	return r;
}


void solucionRecEj1(matrix m){
	if(m.nc>1){
		char Aux[sizeof(m)*1000];
//		matrix_print(m, Aux);
		if((matrix_get(m,0,0)!=matrix_get(m,m.nf-1,0))
				&& (matrix_get(m,0,0)!=matrix_get(m,0,m.nc-1))
				&& (matrix_get(m,0,0)!=matrix_get(m,m.nf-1,m.nc-1))
				&& (matrix_get(m,m.nf-1,0)!=matrix_get(m,0,m.nc-1))
				&& (matrix_get(m,m.nf-1,0)!=matrix_get(m,m.nf-1,m.nc-1))
				&& (matrix_get(m,m.nf-1,m.nc-1)!=matrix_get(m,0,m.nc-1))){
			solucionRecEj1(matrix_view(m,0));
			solucionRecEj1(matrix_view(m,1));
			solucionRecEj1(matrix_view(m,2));
			solucionRecEj1(matrix_view(m,3));
		}else{
			exception++;
		}
	}
}
