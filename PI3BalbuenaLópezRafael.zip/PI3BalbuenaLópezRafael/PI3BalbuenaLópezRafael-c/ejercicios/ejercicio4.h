#include <stdio.h>
#include <stdlib.h>

#include "types/types.h"
#include "types/list.h"
#include "ejemplos/ejemplos2.h"

#include "aFichero.h"

#ifndef EJERCICIO4_H_
#define EJERCICIO4_H_

double solucionRecNoMemEj4(int a, int b);
double solucionRecConMemEj4(int a, int b);
double solucionIterEj4(int a, int b);
void testEj4();

#endif /* EJERCICIO4_H_ */
