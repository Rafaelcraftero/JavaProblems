#include "ejercicio3.h"

void testEj3(){
	char * tokens[2];
	char aux[1000];
	int i=0;
	char buffer[10000]="";
	int n=0;
	double resNoMem=0;
	double resMem=0;
	double resIter=0;
	list ls=list_of_string_of_file("ficheros/PI3Ej3DatosEntrada.txt");
	while(i<ls.size){
		snprintf(aux, sizeof aux, "%s",list_get_string(&ls,i,aux));
		split_text((char*)aux, "=", tokens);
		n=int_parse_s(tokens[1]);
		resNoMem=solucionRecNoMemEj3(n);
		resIter=solucionIterEj3(n);
		resMem=solucionRecConMemEj3(n);
		snprintf(buffer, sizeof buffer, "%sEntero de entrada: %d\n",buffer,n);
		snprintf(buffer, sizeof buffer, "%sF. Recursiva sin memoria: %.0lf\nF. Recursiva con memoria: %.0lf\nF. Iterativa:		  %.0lf\n===============================================================\n",
				buffer,resNoMem,resMem,resIter);
		i++;
	}

	printf("%s",buffer);


}
double solucionRecConMemEj3(int n){
	  double lucker[2000];
	  double bufsize=0;
	  int n3=0;
	  lucker[n3]=-1;
	  if (n>2){
	      n3=n-3;
	      if (bufsize>n3){
	    	  	 return lucker[n3];
	      }
	      else
	    {
	    	  lucker[n3] = 4*solucionRecConMemEj3(n-1) + solucionRecConMemEj3(n-2)
	    		  + solucionRecConMemEj3(n-3);
	      bufsize=n3+1;
	      return lucker[n3];
	    }
	  }
	if(n==0){
		return 2;
	}else if(n==1){
		return 1;
	}else if(n==2){
		return 1;
	}

	return -1;
}

double solucionIterEj3(int n){
	double n0=2, n1=1, n2=1, res=0;
	if(n==0){
		return 2;
	}else if(n==1){
		return 1;
	}else if(n==2){
		return 1;
	}

	for(int i=2;i<n;i++){
		res=(4*n2)+n1+n0;
		n0=n1;
		n1=n2;
		n2=res;
	}

	return res;
}



double solucionRecNoMemEj3(int n){
	if(n==0){
		return 2;
	}else if(n==1){
		return 1;
	}else if(n==2){
		return 1;
	}else{
		return 4*solucionRecNoMemEj3(n-1)+solucionRecNoMemEj3(n-2)
				+solucionRecNoMemEj3(n-3);
	}
	return -1;
}







