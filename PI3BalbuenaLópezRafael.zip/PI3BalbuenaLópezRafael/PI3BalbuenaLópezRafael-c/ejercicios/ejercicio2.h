#include <stdio.h>
#include <stdlib.h>

#include "types/matrices.h"
#include "types/types.h"
#include "types/list.h"
#include "ejemplos/ejemplos2.h"

#include "aFichero.h"

#ifndef EJERCICIO2_H_
#define EJERCICIO2_H_

void solucionRecEj2(list ls, int a, int b, int*res, list*lres, int*position);
int sumList(list ls);
void testEj2();

#endif /* EJERCICIO2_H_ */
