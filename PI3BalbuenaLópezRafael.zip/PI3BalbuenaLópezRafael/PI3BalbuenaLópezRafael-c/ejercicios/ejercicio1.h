#include <stdio.h>
#include <stdlib.h>

#include "types/matrices.h"
#include "types/types.h"
#include "types/list.h"
#include "ejemplos/ejemplos2.h"

#include "aFichero.h"

#ifndef EJERCICIO1_H_
#define EJERCICIO1_H_
void solucionRecEj1(matrix m);
matrix leeEjercicio1(list listas);
void testEj1();
void aCadena(char* fileInit, char Ret[10000]);

#endif /* EJERCICIO1_H_ */
