#include <stdio.h>
#include <stdlib.h>

#include "types/matrices.h"
#include "types/types.h"
#include "types/list.h"
#include "ejemplos/ejemplos2.h"

#include "aFichero.h"

#ifndef EJERCICIO3_H_
#define EJERCICIO3_H_


double solucionRecNoMemEj3(int n);
double solucionRecConMemEj3(int n);
double solucionIterEj3(int n);

void testEj3();


#endif /* EJERCICIO3_H_ */
