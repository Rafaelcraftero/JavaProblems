package test;

import us.lsi.common.Files2;
import us.lsi.common.Pair;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math3.fraction.Fraction;

import ejercicios.Ejercicio1;
import ejercicios.Ejercicio2;
import ejercicios.Ejercicio3;
import ejercicios.Ejercicio4;
public class tests {
	public static void main(String[] args) {
		//testEjercicio1();
		//testEjercicio2();
		//testEjercicio3();
		//testEjercicio4();
	}
	
	
	public static void testEjercicio1(){
		String res1="";
		String res2="";
		String res3="";
		String res4="";
		String res5="";
		String res6="";
		res1=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada1.txt");
		res2=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada2.txt");
		res3=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada3.txt");
		res4=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada4.txt");
		res5=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada5.txt");
		res6=Ejercicio1.aCadena("ficheros/PI3Ej1DatosEntrada6.txt");
		res1=res1+res2+res3+res4+res5+res6;
		System.out.println(res1);
		Files2.toFile(res1,"ficheros/PI3Ej1Resultados.txt");
	}

	public static void testEjercicio2() {
		String aux="";
		String[] StrAux= {};
		int i=0, j=0;
		String fileInit="ficheros/PI3Ej2DatosEntrada.txt";
		List<String> ls=new ArrayList<String>(Files2.linesFromFile(fileInit));
		List<Integer> lsT=new ArrayList<>();
	
		List<List<Integer>> kls=new ArrayList<>();
		
		while(i<ls.size()) {
			StrAux=ls.get(i).replace(",", "").split(" ");
			for(j=0;j<StrAux.length;j++) {

				int aux3=Integer.parseInt(StrAux[j]);
				lsT.add(aux3);
			}
			kls.add(lsT);

			lsT=new ArrayList<>();
			i++;
		}
		int auxRes=0;
		System.out.println();
		for(j=0;j<ls.size();j++) {
			List<List<Integer>> res=new ArrayList<>();
			res=Ejercicio2.solucionRecEj2(kls.get(j), 0,kls.size()-1, auxRes , res);
			
			int pp=res.get(2).get(0)+res.get(0).size();
			aux=aux+"Lista de entrada: "+kls.get(j)+"\n";
			aux=aux+"Secuencia de suma mayor en intervalo ["+res.get(2).get(0)+", "+pp+"):";
			aux=aux+"Subsecuencia = "+res.get(0) +"; Suma obtenida = "+res.get(1)+"\n===============================================================\n";			
			System.out.println("cambiando de tercio");
		}
		System.out.println(aux);
		Files2.toFile(aux,"ficheros/PI3Ej2Resultados.txt");
}

	
	public static void testEjercicio3() {
		String aux="";
		String[] StrAux= {};
		int i=0, j=0;
		String fileInit="ficheros/PI3Ej3DatosEntrada.txt";
		List<String> ls=new ArrayList<String>(Files2.linesFromFile(fileInit));
		List<Integer> lsT=new ArrayList<>();
		
		while(i<ls.size()) {
			StrAux=ls.get(i).split("=");
			for(j=0;j<StrAux.length;j++) {

				int aux3=Integer.parseInt(StrAux[1]);
				lsT.add(aux3);
			}
			i++;
		}
		i=0;
		while(i<lsT.size()) {
			double resNoMem=Ejercicio3.solucionRecNoMemEj3(lsT.get(i));
			double resIter=Ejercicio3.solucionIterEj3(lsT.get(i));
			double resMem=Ejercicio3.solucionRecConMemEj3(lsT.get(i));
			aux=aux+"Entero de entrada: "+ lsT.get(i)+"\nF. Recursiva sin memoria: "+ resNoMem+ "\nF. Recursiva con memoria: "+resMem +"\nF. Iterativa:		  "+ resIter+ "\n===============================================================\n";
			i++;
		}
		System.out.println(aux);
		Files2.toFile(aux,"ficheros/PI3Ej3Resultados.txt");
	}
	
	
	
	
	
	
	
	
	
	//4
	
	
	
	
	public static void testEjercicio4() {
		
		String aux="";
		String[] StrAux= {};
		int i=0, j=0;
		String fileInit="ficheros/PI3Ej4DatosEntrada.txt";
		List<String> ls=new ArrayList<String>(Files2.linesFromFile(fileInit));
		List<Pair<Integer,Integer>> lsT=new ArrayList<>();
		
		while(i<ls.size()) {
			StrAux=ls.get(i).split(",");
			
			for(j=0;j<StrAux.length;j++) {

				Pair<Integer,Integer> aux3=Pair.of(Integer.parseInt(StrAux[0]),Integer.parseInt(StrAux[1]));
				lsT.add(aux3);
			}
			i++;
		}
		i=0;
		aux="Pares de entrada: ";
		double resNoMem=0;
		double resIter=0;
		double resMem=0;
		
		while(i<lsT.size()) {
			resIter=Ejercicio4.solucionIterEj4(lsT.get(i).first,lsT.get(i).second);
			resNoMem=Ejercicio4.solucionRecNoMemEj4(lsT.get(i).first,lsT.get(i).second);
			resMem=Ejercicio4.solucionRecConMemEj4(lsT.get(i).first,lsT.get(i).second);
			aux=aux+ lsT.get(i)+"\nF. Recursiva sin memoria: "+ resNoMem+ "\nF. Recursiva con memoria: "+resMem +"\nF. Iterativa:		  "+ resIter+ "\n===============================================================\n";
			i++;
		}
		System.out.println(aux);
		Files2.toFile(aux,"ficheros/PI3Ej3Resultados.txt");
		
	}
	
	

	
	
}
