package ejercicios;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Pair;

public class Ejercicio4 {

public static double solucionIterEj4(int a, int b){
	double res=0;
	int i=0, j=0;

	List<Pair<Integer,Integer>> ls=new ArrayList<Pair<Integer,Integer> >();
	List<Pair<Integer,Integer> > lsH=ls=new ArrayList<Pair<Integer,Integer> >();
	List<Pair<Integer,Integer> > lsRes=ls=new ArrayList<Pair<Integer,Integer> >();

	if(a<2 && b<2){
		return a+(b*b);

	}else if(a<2 || b<2){
		return (a*a)+b;

	}
	Pair<Integer,Integer> p1=Pair.of(a/2,b-1);
	Pair<Integer,Integer> p2=Pair.of(a/3,b-2);
	Pair<Integer,Integer> p3=Pair.of(a-2,b/4);

	if((p1.first<2 && p1.second<2) || (p1.first<2 || p1.second<2)){
		lsRes.add(p1);
	}else{
		ls.add(p1);

	}

	if((p2.first<2 && p2.second<2) || (p2.first<2 || p2.second<2)){
		lsRes.add(p2);
	}else{
		ls.add(p2);

	}

	if((p3.first<2 && p3.second<2) || (p3.first<2 || p3.second<2)){
		lsRes.add(p3);
	}else{
		ls.add(p3);

	}

	while(ls.size()!=0){
		Pair<Integer,Integer> pl=ls.get(0);

		p1.first=pl.first/2;
		p1.second=pl.second-1;

		p2.first=pl.first/3;
		p2.second=pl.second-2;

		p3.first=pl.first-2;
		p3.second=pl.second/4;

		if((p1.first<2 && p1.second<2) || (p1.first<2 || p1.second<2)){
			lsRes.add(p1);
		}else{
			ls.add(p1);

		}

		if((p2.first<2 && p2.second<2) || (p2.first<2 || p2.second<2)){
			lsRes.add(p2);
		}else{
			ls.add(p2);

		}

		if((p3.first<2 && p3.second<2) || (p3.first<2 || p3.second<2)){
			lsRes.add(p3);
		}else{
			ls.add(p3);

		}

		for(i=1;i<ls.size();i++){

			lsH.add(ls.get(i));
		}
		ls=new ArrayList<Pair<Integer,Integer> >();
		for(j=0;j<lsH.size();j++){
			ls.add(lsH.get(j));
		}
		lsH=new ArrayList<Pair<Integer,Integer> >();
		
		if(ls.size()<1){
			break;
		}
	}
	i=0;
	while(i<lsRes.size()){
		Pair<Integer,Integer> plr=lsRes.get(i);
		  if(plr.first<2 && plr.second<2){
			  res=res+ plr.first+(plr.second*plr.second);
		  }else if(plr.first<2 || plr.second<2){
			  res=res+(plr.first*plr.first)+plr.second;
		  }
		  i++;
	}

	return res;
}

public static double solucionRecNoMemEj4(int a, int b){
	if(a<2 && b<2){
		return a+(b*b);

	}else if(a<2 || b<2){
		return (a*a)+b;

	}else{

		return solucionRecNoMemEj4(a/2, b-1)+solucionRecNoMemEj4(a/3, b-2)
				+solucionRecNoMemEj4(a-2, b/4);
	}
}

@SuppressWarnings("null")
public static double solucionRecConMemEj4(int a, int b){
	  double buffer[] = new double[100];
	  int n3=0;
	  if(!(a<2 && b<2) && !(a<2 || b<2) ){
		  n3++;
		  buffer[n3] = solucionRecNoMemEj4(a/2, b-1)+solucionRecNoMemEj4(a/3, b-2)
							+solucionRecNoMemEj4(a-2, b/4);
	  	  return buffer[n3];
	  }
	  if(a<2 && b<2){
		  return a+(b*b);
	  }else if(a<2 || b<2){
		  return (a*a)+b;
	  }
	return -1;
}
	
	
	
	
	
}
