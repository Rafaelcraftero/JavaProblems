package ejercicios;


public class Ejercicio3 {

	@SuppressWarnings("null")
	public static double solucionRecConMemEj3(int n){
		  double lucker[] = new double[100];
		  double bufsize=0;
		  int n3=0;
		  lucker[n3]=-1;
		  if (n>2){
		      n3=n-3;
		      if (bufsize>n3){
		    	  	 return lucker[n3];
		      }
		      else
		    {
		    	  lucker[n3] = 4*solucionRecConMemEj3(n-1) + solucionRecConMemEj3(n-2)
		    		  + solucionRecConMemEj3(n-3);
		      bufsize=n3+1;
		      return lucker[n3];
		    }
		  }
		if(n==0){
			return 2;
		}else if(n==1){
			return 1;
		}else if(n==2){
			return 1;
		}

		return -1;
	}

	public static double solucionIterEj3(int n){
		double n0=2, n1=1, n2=1, res=0;
		if(n==0){
			return 2;
		}else if(n==1){
			return 1;
		}else if(n==2){
			return 1;
		}

		for(int i=2;i<n;i++){
			res=(4*n2)+n1+n0;
			n0=n1;
			n1=n2;
			n2=res;
		}

		return res;
	}



	public static double solucionRecNoMemEj3(int n){
		if(n==0){
			return 2;
		}else if(n==1){
			return 1;
		}else if(n==2){
			return 1;
		}else{
			return 4*solucionRecNoMemEj3(n-1)+solucionRecNoMemEj3(n-2)
					+solucionRecNoMemEj3(n-3);
		}
	}



	
	
}
