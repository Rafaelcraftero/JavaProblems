package ejercicios;
import org.apache.commons.math3.Field;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.fraction.Fraction;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Array;
import us.lsi.common.Files2;
import us.lsi.common.Matrix;
import us.lsi.geometria.Punto2D;
public class Ejercicio1 {
	

	public static int exception=0;

public static String aCadena(String fileInit){
//	Matrix<Fraction> r=new Matrix<>(Fraction.ZERO.getField(), null);
	List<String> lectura=new ArrayList<String>(Files2.linesFromFile(fileInit));
	String[] StrAux= {};
	int i=0, j=0;
	List<Fraction> wF=new ArrayList<>();
	List<List<Fraction>> w=new ArrayList<>();
	while(i<lectura.size()) {
		StrAux=lectura.get(i).split(" ");
		for(j=0;j<StrAux.length;j++) {
			int aux2=Integer.parseInt(StrAux[j]);
			wF.add(Fraction.getReducedFraction(aux2, 1));
		}
		
		w.add(wF);
		wF=new ArrayList<>();
		i++;
	}

	Matrix<Fraction> r=leeEjercicio1(w);
	String mat="";
	String aux="";
	String res="";
	String bool="";
	solucionRecEj1(r);
	
	if(exception!=0){
		bool="false";
		exception=0;
	}else {
		bool="true";
	}
	
	if(r.nf<=32){
		for (i = 0; i < r.nf; i++) {
			for (j = 0; j < r.nc; j++){
				mat=mat+r.get(i, j)+" ";
			}
			mat=mat+"\n";
		}

		res=res+"Matriz de entrada ("+r.nf+"*"+r.nc+"):\n"+mat+"\nEs matriz valida?"+bool+"\n================================================================\n";

	}else{
		res=res+"Matriz de entrada ("+r.nf+"*"+r.nc+")";
		res=res+". No se muestra dado el tamaño\n";
		res=res+"\nEs matriz valida?"+bool+"\n================================================================\n";

	}

	return res;

}

@SuppressWarnings("null")
public static Matrix<Fraction> leeEjercicio1(List<List<Fraction>> listas){
	int i=0, i2=0;
//	System.out.println(listas.size());
	Fraction res[][]=new Fraction[listas.size()][listas.size()];

	List<Fraction> Aux = new ArrayList<>() ;
	while(i<listas.size()){
		i2=0;
		Aux = listas.get(i);
		while(i2<listas.size()){
			res[i][i2]=Aux.get(i2);
			i2++;
		}

		i++;

	}
	Matrix<Fraction> r=Matrix.of(Fraction.ONE.getField(), res);
	//Matrix<Fraction> r = Matrix.zero(Fraction.ONE.getField(),Aux.size(),Aux.size());
	//r.datos=res;
	//System.out.println(r.nc);
	return r;
}


public static int solucionRecEj1(Matrix<Fraction> m){
	if(m.nc>1){
		if((m.get(0, 0)!=m.get(m.nf-1, 0))
				&& (m.get(0, 0)!=m.get(0, m.nc-1))
				&& (m.get(0, 0)!=m.get(m.nf-1, m.nc-1))
				&& (m.get(m.nf-1, 0)!=m.get(0, m.nc-1))
				&& (m.get(m.nf-1, 0)!=m.get(m.nf-1, m.nc-1))
				&& (m.get(m.nf-1, m.nc-1)!=m.get(0, m.nc-1))){
			
			return solucionRecEj1(m.view(0))+solucionRecEj1(m.view(1))+
					solucionRecEj1(m.view(2))+solucionRecEj1(m.view(3));

		}else{
			return 1;
		}
	}
	return 0;
	
}
	
	
}
