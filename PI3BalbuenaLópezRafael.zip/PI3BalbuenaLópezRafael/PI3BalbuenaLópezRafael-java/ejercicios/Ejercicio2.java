package ejercicios;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio2 {

public static List<List<Integer>> solucionRecEj2(List<Integer> ls, int a, int b, int res, List<List<Integer>> G){

	if(a<b){
		List<Integer> k=new ArrayList<>();
		k =ls.subList(a, b);
		int aux=sumList(k);
		if( b>0 && a<ls.size()-1){
			if(res<=aux){
				res=aux;
				List<Integer> position=new ArrayList<>();
				List<Integer> resL=new ArrayList<>();
				position.add(a);
				resL.add(aux);
				
				G.add(0,ls.subList(a, b));
				G.add(1,resL);
				G.add(2,position);
			}
			if(b>a+1){
				solucionRecEj2(ls, a, b-1, res , G);
			}
			if(res<=aux){
				res=aux;
				List<Integer> position=new ArrayList<>();
				List<Integer> resL=new ArrayList<>();
				position.add(a);
				resL.add(aux);
				
				G.add(0,ls.subList(a, b));
				G.add(1,resL);
				G.add(2,position);

			}
			solucionRecEj2(ls, a+1,ls.size()-1, res , G);
		}
	}
	return G;
}
public static int sumList(List<Integer> ls){
	int res=0;
	for(int i=0;i<ls.size();i++){
		res+=ls.get(i);

	}
	return res;
}
	
}
