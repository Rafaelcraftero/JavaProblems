module PI5BalbuenaL�pezRafael {
	exports ejercicios;
	exports test;
	requires partecomun;
    requires datos_compartidos;
    requires grafos;
    requires solve;
    requires ejemplos_de_grafos;
	requires org.jgrapht.core;
}