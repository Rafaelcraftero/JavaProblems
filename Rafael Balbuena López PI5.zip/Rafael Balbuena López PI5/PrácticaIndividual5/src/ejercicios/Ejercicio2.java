package ejercicios;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.jgrapht.alg.color.GreedyColoring;
import org.jgrapht.graph.SimpleGraph;
import test.clases;
import test.grupos;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.common.Files2;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio2 {
	
	public static List<Set<grupos>> grupos(SimpleGraph<grupos, clases> graph){
		return  new GreedyColoring<grupos, clases>(graph).getColoring().getColorClasses();
	}
	
	public static void colereadoejercicio2(SimpleGraph<grupos, clases> graph, String fichero,  List<Set<grupos>> grupos) {
		Color[] cl= {Color.black, Color.green , Color.yellow, Color.gray, Color.cyan, Color.orange, Color.magenta, Color.blue, Color.red};
		List<Color> color= new ArrayList<GraphColors.Color>();
		color.addAll(Arrays.asList(cl));

		Graphs2.toDot(graph,fichero, 
				x->x.getNombre(),
				y->"",
				x->GraphColors.getColor(color.get(grupos.indexOf(grupos.stream().filter(t->t.contains(x)).collect(Collectors.toList()).get(0)) % color.size())), 
				y->GraphColors.getColor(Color.black));
		
		
	}
	
	
	public static List<grupos> leerDatosEj2(String fichero){
		
		List<String> lectura = Files2.linesFromFile(fichero);
		
		List<grupos> lista = new ArrayList<grupos>();
			
		for(int i=0;i<lectura.size();i++) {
			String[] kk=lectura.get(i).split(":");
			String grupoPrs=kk[1].trim();
			String[] cadaGrupo = grupoPrs.split(",");
			String profesores= kk[0].trim();
	
			for(int j=0;j<cadaGrupo.length;j++) {
				grupos gruposDelProfesor= grupos.ofName(cadaGrupo[j].trim());
				if(lista.stream().anyMatch(x->x.getNombre().contains(gruposDelProfesor.getNombre().trim()))) {
					lista.stream().filter(x->x.getNombre().contains(gruposDelProfesor.getNombre().trim())).findFirst().get().addProfesores(profesores);
					
				}else {
					
					gruposDelProfesor.addProfesores(profesores.trim());
					lista.add(gruposDelProfesor);
				}
			}			
		}
		
		return lista;
	}
	
	public static void aficheroEj2(String file, List<grupos> lista) {
		String cadena = "#VERTEX#\n";
		for(int i=0;i<lista.size();i++) {
			cadena = cadena + String.format("%s, %s\n", lista.get(i).getNombre(), lista.get(i).getProfesores().toString().replace(",", ":").replace("}", "").replace("{", ""));
			
		}
		cadena=cadena+"#EDGE#\n";

		
		for(int j=0;j<lista.size(); j++) {
			
			for(int k=j+1;k<lista.size();k++) {
				int[] pp= {k};
				cadena =lista.get(j).getProfesores().stream().anyMatch(x->lista.get(pp[0]).getProfesores().contains(x))? cadena+ String.format("%s,%s\n", lista.get(j), lista.get(k)): cadena;
				
			}
		}
		Files2.toFile(cadena, file);
	}
	
	
	public static SimpleGraph<grupos, clases> leeGrafoCG(String fichero){
		return GraphsReader.newGraph(fichero, grupos::ofFormat, clases::ofFormat, ()->new SimpleGraph<grupos, clases>(grupos::of, clases::of, false));
	}	

	

}
