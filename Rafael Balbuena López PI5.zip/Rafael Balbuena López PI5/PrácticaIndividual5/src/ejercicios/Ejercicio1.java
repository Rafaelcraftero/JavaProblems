package ejercicios;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.interfaces.ShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.vertexcover.GreedyVCImpl;
import org.jgrapht.graph.SimpleGraph;
import org.jgrapht.graph.SimpleWeightedGraph;

import test.amistades;
import test.persona;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio1 {
	
	
	//Apartado A
	
	
	public static Map<Integer, List<persona>> cantidadDeAmigos(Graph<persona,amistades> graph){
		Map<Integer, List<persona>> M = new HashMap<Integer, List<persona>>();
		int i=0;
		List<persona> lh= graph.vertexSet().stream().collect(Collectors.toList());
		while(lh.size()>i){
				
			if(!M.containsKey(graph.degreeOf(lh.get(i)))) {				
				M.put(graph.degreeOf(lh.get(i)), List.of(lh.get(i)));	
			}
			else {
				
				List<persona> lk= new ArrayList<persona>(M.get(graph.degreeOf(lh.get(i))));
				lk.add(lh.get(i));
				M.put(graph.degreeOf(lh.get(i)), lk);
				
			}
			i++;
		}
	return M;	
	}
	
	public static List<persona> maxNumAmigos(Map<Integer, List<persona>> M){
		return M.isEmpty()? new ArrayList<persona>() : 
			M.get(M.keySet().stream().collect(Collectors.toList()).stream().max(Comparator.naturalOrder()).get());
		
	}
	public static List<persona> ningunNumAmigos(Map<Integer, List<persona>> M){
		return M.containsKey(0)? M.get(0) : new ArrayList<persona>();
	}
	
	public static SimpleWeightedGraph<persona,amistades> leeGrafoAP(String fichero){
		SimpleWeightedGraph<persona,amistades> graph = GraphsReader.newGraph(fichero, 
				persona::ofFormat, amistades::ofFormat,
				Graphs2::simpleWeightedGraph,amistades::getP1);
		
		return graph;
	}	
	
	public static void coloreadoDeGrafo(SimpleGraph<persona, amistades> graph, List<persona> sinAmigos, List<persona> masAmigos, String fichero) {	
		Graphs2.toDot(graph, fichero,x->x.getPersonas(),y->"",
				x->GraphColors.getColor(sinAmigos.contains(x)? Color.blue: masAmigos.contains(x)? Color.red:Color.black),
				y->GraphColors.getColor(Color.black));	
	}
	
	
	//Apartado B
	
	
	public static GraphPath<persona, amistades> caminoMasCorto(persona personaA, persona personaB, SimpleGraph<persona, amistades>  graph){
		ShortestPathAlgorithm<persona, amistades> a = new DijkstraShortestPath<persona, amistades>(graph);
		return  a.getPath(personaA,personaB);
		
		
	}
	
	public static void coloreadodeGrafoCamino(SimpleGraph<persona, amistades> graph, GraphPath<persona, amistades> camino, String fichero) {	
		Graphs2.toDot(graph, fichero,x->x.getPersonas(),y->"",
				x->GraphColors.getColor(camino.getVertexList().contains(x)? Color.blue: Color.black),
				y->GraphColors.getColor(camino.getEdgeList().contains(y)? Color.blue: Color.black));	
	}
	
	
	//Apartado C
	
	
	public static void coloreadodeGrafoSets(SimpleGraph<persona, amistades> graph, String fichero) {	
		ConnectivityInspector<persona, amistades> cI = new ConnectivityInspector<persona, amistades>(graph);
		List<Set<persona>> lk = cI.connectedSets().stream().collect(Collectors.toList());	
		Color[] cl= {Color.green , Color.yellow, Color.gray, Color.cyan, Color.orange, Color.magenta, Color.blue, Color.black, Color.red};
		List<Color> color= new ArrayList<GraphColors.Color>();
		color.addAll(Arrays.asList(cl));
		Graphs2.toDot(graph, fichero,
				x->x.getPersonas(),
				y->"",
				x->GraphColors.getColor(color.get(lk.indexOf(lk.stream().filter(t->t.contains(x)).collect(Collectors.toList()).get(0)) % color.size())),
				y->GraphColors.getColor(color.get(lk.indexOf(lk.stream().filter(t->t.contains(y.getPersonaA())).collect(Collectors.toList()).get(0)) % color.size()))
		);	
	}
	
	
	//Apartado D
	
	public static Set<persona> verticesEncuesta(SimpleGraph<persona, amistades> graph) {
			return new GreedyVCImpl<persona, amistades>(graph).getVertexCover();
	}
	public static void coloreadodeeEncuesta(SimpleGraph<persona, amistades> graph, Set<persona> influencia, String fichero) {
		Graphs2.toDot(graph, fichero,
				x->x.getPersonas(),
				y->"",
				x->GraphColors.getColor(influencia.contains(x)? Color.blue: Color.black),
				y->GraphColors.getColor(Color.black));	
		
		
	}
}