package ejercicios;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.jgrapht.graph.SimpleDirectedGraph;
import test.asignatura;
import test.requisitos;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.common.Files2;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class Ejercicio3 {

	public static List<asignatura> leerDatosEj3(String fichero){
		
		List<String> lectura = Files2.linesFromFile(fichero);
		
		List<asignatura> lista = new ArrayList<asignatura>();
			
		for(int i=0;i<lectura.size();i++) {
			Set<asignatura> asig=new HashSet<asignatura>();
			String[] kk=lectura.get(i).split(":");
			String namae=kk[0].trim();
			String[] asignaturas= kk[1].replace("{", "").replace("}", "").replace("[", "").replace("]", "").trim().split(",");
	
			for(int j=0;j<asignaturas.length;j++) {
				if(!asignaturas[j].isEmpty() || asignaturas[j].isBlank()) {
					asignatura asignaturasAuxr= asignatura.ofName(asignaturas[j].trim());
					asig.add(asignaturasAuxr);
				}
				asignatura aux=asignatura.ofAll(namae, asig);
				lista.add(aux);
			}			
		}
		
		return lista;
	}
	
	
	public static void aficheroEj3(String file, List<asignatura> lista) {
		String cadena = "#VERTEX#\n";
		for(int i=0;i<lista.size();i++) {
			cadena = cadena + String.format("%s, %s\n", lista.get(i).getNombre(), lista.get(i).getRequisitos().toString().replace(",", ":").replace("}", "").replace("{", "").replace("[", "").replace("]", ""));
			
		}
		cadena=cadena+"#EDGE#\n";

		
		for(int j=0;j<lista.size(); j++) {
			Set<asignatura> asig = lista.get(j).getRequisitos();
			for(int k=(j+1)%lista.size();k!=j;k=(k+1)%lista.size()) {
				if(asig.size()>=1 && !asig.contains(asignatura.of())) {
					for(asignatura asigAux:asig) {
						
						if(asigAux.getNombre().equals(lista.get(k).getNombre())) {
							cadena=cadena + String.format("%s, %s\n", lista.get(k), lista.get(j));

							
						}
					}
				}
			}
		}
		Files2.toFile(cadena, file);
	}
	
	public static SimpleDirectedGraph<asignatura, requisitos> leeGrafoEj3(String file){		
		return GraphsReader.newGraph
				(file, asignatura::ofFormat, requisitos::ofFormat, ()-> new SimpleDirectedGraph<asignatura, requisitos>(asignatura::of, requisitos::of, false));
				
	}
	
	
	//Apartado A
	public static List<asignatura> ordenarEj3(SimpleDirectedGraph<asignatura, requisitos> graph){
		Set<asignatura> cursado=sinRequisitosParaCursar(graph);
		List<asignatura> lista = cursado.stream().collect(Collectors.toList());
		while(!graph.vertexSet().equals(lista.stream().collect(Collectors.toSet()))) {
			Set<asignatura> porCursar = proximoAnyoAsignaturas(graph, lista.stream().collect(Collectors.toSet()));
			cursado.addAll(porCursar);
			for(asignatura asig:porCursar) {
				if(!lista.contains(asig)) {
					lista.add(asig);
				}
			}
		}
		return lista;
	}
	
	
	//Apartado B
	public static Set<asignatura> sinRequisitosParaCursar(SimpleDirectedGraph<asignatura, requisitos> graph){
		
		return 	graph.vertexSet().stream().filter(x->graph.inDegreeOf(x)==0).collect(Collectors.toSet());
	}
	
	public static void coloreadoSinRequisitos(SimpleDirectedGraph<asignatura, requisitos> graph, List<asignatura> sinRequisitos, String fichero) {
		
		  		Graphs2.toDot(graph, fichero,x->x.getNombre(),
		  		y->"",
				x->GraphColors.getColor(sinRequisitos.contains(x)? Color.blue: Color.black),
				y->GraphColors.getColor(Color.black));	
		  
		
	}
	//Apartado C

	public static Set<asignatura> proximoAnyoAsignaturas(SimpleDirectedGraph<asignatura, requisitos> graph, Set<asignatura> aprobadas){
		Set<asignatura> res =sinRequisitosParaCursar(graph).stream().filter(x->!aprobadas.stream().
				map(y->y.getNombre()).collect(Collectors.toList()).contains(x.getNombre())).collect(Collectors.toSet());
		List<asignatura> asigAux = graph.vertexSet().stream().filter(x->graph.inDegreeOf(x)!=0).collect(Collectors.toList());
		List<asignatura> asigAux2= new ArrayList<asignatura>();
		
		for(int i=0;i<asigAux.size();i++) {
			if(!aprobadas.stream().map(x->x.getNombre()).collect(Collectors.toList()).contains(asigAux.get(i).getNombre())) {
				asigAux2.add(asigAux.get(i));
			}
			
		}
		for(int i=0;i<asigAux2.size();i++) {
				if(aprobadas.stream().map(t->t.getNombre()).collect(Collectors.toList()).containsAll(graph.incomingEdgesOf(asigAux2.get(i)).stream().map(y->y.getFuente().getNombre()).collect(Collectors.toList()))) {
				res.add(asigAux2.get(i));
			}

		}
		return res;
	}
	
	public static void coloreadoSegunAnyo(SimpleDirectedGraph<asignatura, requisitos> graph, List<asignatura> esteAnyo, List<asignatura> elSiguienteAnyo, String fichero) {
		
  		Graphs2.toDot(graph, fichero,x->x.getNombre(),
  		y->"",
		x->GraphColors.getColor(esteAnyo.stream().map(t->t.getNombre()).collect(Collectors.toList()).contains(x.getNombre())? Color.blue:  elSiguienteAnyo.stream().map(t->t.getNombre()).collect(Collectors.toList()).contains(x.getNombre())? Color.red: Color.black),
		y->GraphColors.getColor(Color.black));	
  

}
}
