package test;

import java.util.HashSet;
import java.util.Set;

public class grupos {

	private String nombre;
	private Set<String> profesores;

	private grupos() {
		this.nombre="";
		this.profesores=new HashSet<String>();
	}


	private grupos(String nombre) {
		super();
		this.nombre=nombre;
		this.profesores=new HashSet<String>();
	}

	private grupos(String[] formato) {
		this.nombre=formato[0];
		this.profesores=new HashSet<String>();
		for(String p:formato[1].split(":")) {
			this.profesores.add(p.trim());

		}
	}

	public static grupos ofName(String nombre) {
		return new grupos(nombre);
	}

	public static grupos ofFormat(String[] formato) {
		return new grupos(formato);
	}

	public static grupos of() {
		return new grupos("");
	}

	public void addProfesores(String Profesores) {
		getProfesores().add(Profesores);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Set<String> getProfesores() {
		return this.profesores;
	}

	public void setProfesores(Set<String> profesores) {
		this.profesores = profesores;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((profesores == null) ? 0 : profesores.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		grupos other = (grupos) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (profesores == null) {
			if (other.profesores != null)
				return false;
		} else if (!profesores.equals(other.profesores))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return getNombre();
	}




}
