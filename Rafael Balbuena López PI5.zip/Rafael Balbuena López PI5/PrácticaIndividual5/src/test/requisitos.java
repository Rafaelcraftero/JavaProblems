package test;

public class requisitos {

	private asignatura destino;
	
	private asignatura fuente;
	
	private requisitos() {
		this.destino=asignatura.of();
		this.fuente=asignatura.of();
	}

	private requisitos(asignatura fuente, asignatura destino) {
		super();
		this.destino=destino;
		this.fuente=fuente;
	}

	private requisitos(asignatura fuente, asignatura destino, String[] formato) {
		super();
		this.destino=destino;
		this.fuente=fuente;
	}
	public double getP1() {
		return 1;
	}

	
	public static requisitos ofGrupos(asignatura fuente, asignatura destino) {
		return new requisitos(fuente, destino);
	}

	public static requisitos ofFormat(asignatura fuente, asignatura destino, String[] formato) {
		return new requisitos(fuente, destino, formato);
	}

	public static requisitos of() {
		return new requisitos();
	}

	public asignatura getDestino() {
		return destino;
	}

	public void setDestino(asignatura destino) {
		this.destino = destino;
	}

	public asignatura getFuente() {
		return fuente;
	}

	public void setFuente(asignatura fuente) {
		this.fuente = fuente;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((destino == null) ? 0 : destino.hashCode());
		result = prime * result + ((fuente == null) ? 0 : fuente.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		requisitos other = (requisitos) obj;
		if (destino == null) {
			if (other.destino != null)
				return false;
		} else if (!destino.equals(other.destino))
			return false;
		if (fuente == null) {
			if (other.fuente != null)
				return false;
		} else if (!fuente.equals(other.fuente))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "requisitos [destino=" + destino + ", fuente=" + fuente + "]";
	}


	
}
