package test;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.graph.SimpleGraph;

import ejercicios.Ejercicio1;
import ejercicios.Ejercicio2;
import ejercicios.Ejercicio3;
import us.lsi.colors.GraphColors.Color;
import us.lsi.common.Files2;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class tests {
	public static void main(String[] args) {
	
	//  Ejercicio 1	
	//	ejercicio1ATest();
	//	ejercicio1BTest();
	//	ejercicio1CTest();
	//	ejercicio1DTest();
		
	//  Ejercicio 2
	//	ejercicio2ATest();
	//  ejercicio2BTest();
		
	//	Ejercicio 3
	//	ejercicio3ATest();
	//	ejercicio3BTest();
	//	ejercicio3CTest();
	}
	
	public static void ejercicio1ATest() {
		String file="ficheros/PI5Ej1DatosEntrada.txt";
		SimpleGraph<persona, amistades>  graph = Ejercicio1.leeGrafoAP(file);
		Map<Integer, List<persona>> M= Ejercicio1.cantidadDeAmigos(graph);
		Ejercicio1.coloreadoDeGrafo(graph, Ejercicio1.maxNumAmigos(M), Ejercicio1.ningunNumAmigos(M), "ficheros/PI5Ej1AResultados.txt");
		String cadena="Los miembros con 0 amigos son: "+ Ejercicio1.ningunNumAmigos(M) +"\n";
		 M.entrySet().stream().filter(x->x.getValue().stream().collect(Collectors.toList()).contains(Ejercicio1.ningunNumAmigos(M).get(0)))
		 .map(y->y.getKey()).collect(Collectors.toList()).get(0);
		cadena= cadena + "Los miembros con m�s amigos (" +  M.entrySet().stream().filter(x->x.getValue().stream().collect(Collectors.toList())
				.contains(Ejercicio1.maxNumAmigos(M).get(0))).map(y->y.getKey()).collect(Collectors.toList()).get(0) + ") son:" +Ejercicio1.maxNumAmigos(M);
		System.out.println(cadena);
		
	}
	
	
	
	public static void ejercicio1BTest() {
		String file="ficheros/PI5Ej1DatosEntrada.txt";
		SimpleGraph<persona, amistades>  graph = Ejercicio1.leeGrafoAP(file);

		persona personaA = persona.ofName("Ramiro");
		persona personaB = persona.ofName("Juan");
		if(graph.vertexSet().contains(personaA) && graph.vertexSet().contains(personaB)) {
			GraphPath<persona, amistades> gp = Ejercicio1.caminoMasCorto(personaA, personaB, graph);
			if(gp!=null) {
				String cadena= "La lista m�s corta entre Juan y Ramiro es: "+ gp.getVertexList();
				System.out.println(cadena);
				Ejercicio1.coloreadodeGrafoCamino(graph, gp, "ficheros/PI5Ej1BResultados.txt"); 			
			}else {
				System.out.println("No existe un camino");
			}

		}else {
			System.out.println("Al menos una persona no est� en el grafo");
			
		}

	}	
	
	public static void ejercicio1CTest() {
		String file="ficheros/PI5Ej1DatosEntrada.txt";
		SimpleGraph<persona, amistades>  graph = Ejercicio1.leeGrafoAP(file);
		ConnectivityInspector<persona, amistades> cI = new ConnectivityInspector<persona, amistades>(graph);
		List<Set<persona>> lk = cI.connectedSets().stream().collect(Collectors.toList());	
		Ejercicio1.coloreadodeGrafoSets(graph, "ficheros/PI5Ej1CResultados.txt");
		
		List<String> leerficheros=Files2.linesFromFile("ficheros/PI5Ej1CResultados.txt");
		Map<String, Color> ms= new HashMap<String, Color>();
		if(leerficheros.size()>2) {
			for(int j=1;j<leerficheros.size()-1;j++) {
				String[] aux=leerficheros.get(j).split("color=");
				String[] aux2=aux[1].split("label=");
				aux2[1]=aux2[1].replace(" ];", "").replace("\"", "").trim();
				aux2[0]=aux2[0].replace("\"", "").trim();				
				ms.put(aux2[1], Color.valueOf(aux2[0]));
			}
		}
	
		String cadena= "Exiten "+lk.size() +" grupos. Su composicion es:\n"; 
		for(int i=0;i<lk.size();i++) {
			cadena=cadena+"Grupo " +ms.get(lk.get(i).stream().findFirst().get().getPersonas())+" (" + lk.get(i).size();
		    if(lk.get(i).size()>1) {
		    	cadena= cadena + " usuarios)\n";
		    }
		    else{
		    	cadena= cadena + " usuario)\n";
		    }
		    cadena = cadena + lk.get(i) + "\n";
		}
		System.out.println(cadena);
	}	
	
	public static void ejercicio1DTest() {
		
		String file="ficheros/PI5Ej1DatosEntrada.txt";
		SimpleGraph<persona, amistades>  graph = Ejercicio1.leeGrafoAP(file);
		Ejercicio1.coloreadodeeEncuesta(graph, Ejercicio1.verticesEncuesta(graph), "ficheros/PI5Ej1DResultados.txt");
		String cadena= "Se enviar�n 3 cuestionarios a los siguientes miembros:\n" + Ejercicio1.verticesEncuesta(graph);
		System.out.println(cadena);
		
	}
	
	public static void ejercicio2ATest() {

		String file="ficheros/PI5Ej2DatosEntrada.txt";
		List<grupos> kk=   Ejercicio2.leerDatosEj2(file);
		Ejercicio2.aficheroEj2("ficheros/Ej2Aux.txt", kk);
		SimpleGraph<grupos, clases>  graph= Ejercicio2.leeGrafoCG("ficheros/Ej2Aux.txt");

		List<Set<grupos>> colores =Ejercicio2.grupos(graph);
		String cadena="Se han requerido "+ colores.size()+ " franjas horarias.\n";
		cadena = cadena + "Grupos a impartirse segun la franja horaria\n";
		for(int i=1;i<=colores.size();i++) {
			cadena= cadena+"Franja n�"+i+":"+colores.get(i-1)+"\n";
		}
		System.out.println(cadena);
	}
	public static void ejercicio2BTest() {
	
		String file="ficheros/PI5Ej2DatosEntrada.txt";
		List<grupos> kk=   Ejercicio2.leerDatosEj2(file);
		Ejercicio2.aficheroEj2("ficheros/Ej2Aux.txt", kk);
		SimpleGraph<grupos, clases>  graph= Ejercicio2.leeGrafoCG("ficheros/Ej2Aux.txt");
		Ejercicio2.colereadoejercicio2(graph, "ficheros/PI5Ej2BResultados.txt", Ejercicio2.grupos(graph));
	
	}
	
	public static void ejercicio3ATest() {
		
		String file="ficheros/PI5Ej3DatosEntrada.txt";
		List<asignatura> kk=   Ejercicio3.leerDatosEj3(file);
		Ejercicio3.aficheroEj3("ficheros/Ej3Aux.txt", kk);
		SimpleDirectedGraph<asignatura, requisitos> graph = Ejercicio3.leeGrafoEj3("ficheros/Ej3Aux.txt");
		List<asignatura>lista=Ejercicio3.ordenarEj3(graph);
		String cadena = "Una de las posibles ordenaciones v�lidas es la siguiente:\n"; 
		for(int i=0;i<lista.size();i++) {
			cadena=cadena+lista.get(i).getNombre()+"\n";
			
		}
		System.out.println(cadena);
		
	}
	
	public static void ejercicio3BTest() {
		
		String file="ficheros/PI5Ej3DatosEntrada.txt";
		List<asignatura> kk=   Ejercicio3.leerDatosEj3(file);
		Ejercicio3.aficheroEj3("ficheros/Ej3Aux.txt", kk);
		SimpleDirectedGraph<asignatura, requisitos> graph = Ejercicio3.leeGrafoEj3("ficheros/Ej3Aux.txt");
		List<asignatura> kj= Ejercicio3.sinRequisitosParaCursar(graph).stream().collect(Collectors.toList());	
		Ejercicio3.coloreadoSinRequisitos(graph, kj, "ficheros/PI5Ej3BResultados.txt");
		
		String cadena="Las asignaturas que no requieren aprobar otra antes son:\n";
		for(int i=0;i<kj.size();i++) {
			cadena=cadena+kj.get(i).getNombre()+"\n";
		}
		System.out.println(cadena);
	}
	
	
	public static void ejercicio3CTest() {
		
		String file="ficheros/PI5Ej3DatosEntrada.txt";
		List<asignatura> kk=   Ejercicio3.leerDatosEj3(file);
		Ejercicio3.aficheroEj3("ficheros/Ej3Aux.txt", kk);
		SimpleDirectedGraph<asignatura, requisitos> graph = Ejercicio3.leeGrafoEj3("ficheros/Ej3Aux.txt");
		Set<asignatura> op =new HashSet<asignatura>(Set.of(asignatura.ofName("Asignatura_01"), asignatura.ofName("Asignatura_02"),asignatura.ofName("Asignatura_03"), 
				asignatura.ofName("Asignatura_04"), asignatura.ofName("Asignatura_05"), asignatura.ofName("Asignatura_06"), asignatura.ofName("Asignatura_07"),
				asignatura.ofName("Asignatura_08"), asignatura.ofName("Asignatura_11")));
				
		List<asignatura> siguiente = Ejercicio3.proximoAnyoAsignaturas(graph, op).stream().collect(Collectors.toList());
		
		Ejercicio3.coloreadoSegunAnyo(graph, op.stream().collect(Collectors.toList()), siguiente, "ficheros/PI5Ej3CResultados.txt");
		
		String cadena ="\nTest 1. Conjunto = {Asignatura_01, Asignatura_02, Asignatura_03, Asignatura_04, Asignatura_05}\n";
		cadena =cadena + "Test 1 � El alumno puede cursar las siguientes asignaturas: \n";
		cadena =cadena+ Ejercicio3.proximoAnyoAsignaturas(graph, Ejercicio3.sinRequisitosParaCursar(graph))+"\n\n";
		cadena =cadena + "Test 2. Conjunto =  {Asignatura_01, Asignatura_02, Asignatura_03, Asignatura_04, Asignatura_05,"
				+ " Asignatura_06, Asignatura_07, Asignatura_08, Asignatura_11}\n";
		cadena =cadena + "Test 2 � El alumno puede cursar las siguientes asignaturas: \n";
		cadena =cadena+ siguiente +"\n\n";
		System.out.println(cadena);
		
	}
	
	
	
	
}
