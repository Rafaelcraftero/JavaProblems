package test;

public class persona {

	private String Persona;
	
	public static  persona ofName(String nombre) {
		return new persona(nombre);
	}

	public static persona ofFormat(String[] formato) {
		return new persona(formato);
	}
	
	public static persona of() {
		return new persona("");
	}

	public String getPersonas() {
		return Persona;
	}

	public void setPersonas(String personas) {
		
		this.Persona = personas;
	}
	public String toString() {
		return Persona;
	}

	private persona(String personas) {
		super();
		this.Persona = personas;
	}
	private persona(String[] formato) {
		super();
		this.Persona = formato[0];
	}	

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Persona == null) ? 0 : Persona.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		persona other = (persona) obj;
		if (Persona == null) {
			if (other.Persona != null)
				return false;
		} else if (!Persona.equals(other.Persona))
			return false;
		return true;
	}

}

