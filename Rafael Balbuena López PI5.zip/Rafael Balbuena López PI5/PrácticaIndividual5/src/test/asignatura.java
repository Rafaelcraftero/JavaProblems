package test;

import java.util.HashSet;
import java.util.Set;

public class asignatura {

	private String nombre;
	private Set<asignatura> requisitos;

	private asignatura() {
		this.nombre="";
		this.requisitos=new HashSet<asignatura>();
	}


	private asignatura(String nombre) {
		super();
		this.nombre=nombre;
		this.requisitos=new HashSet<asignatura>();
	}
	
	private asignatura(String nombre, Set<asignatura> requisitos) {
		super();
		this.nombre=nombre;
		this.requisitos=requisitos;
	}

	private asignatura(String[] formato) {
		this.nombre=formato[0];
		this.requisitos=new HashSet<asignatura>();
		for(String p:formato[1].split(":")) {
			this.requisitos.add(asignatura.ofName(p.trim()));

		}
	}

	public static asignatura ofName(String nombre) {
		return new asignatura(nombre);
	}

	public static asignatura ofAll(String nombre, Set<asignatura> requisitos) {
		return new asignatura(nombre, requisitos);
	}

	public static asignatura ofFormat(String[] formato) {
		return new asignatura(formato);
	}

	public static asignatura of() {
		return new asignatura("");
	}

	public void addRequisitos(asignatura asig) {
		getRequisitos().add(asig);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Set<asignatura> getRequisitos() {
		return this.requisitos;
	}

	public void setAsignatura(Set<asignatura> requisitos) {
		this.requisitos = requisitos;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((requisitos == null) ? 0 : requisitos.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		asignatura other = (asignatura) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (requisitos == null) {
			if (other.requisitos != null)
				return false;
		} else if (!requisitos.equals(other.requisitos))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return getNombre();
	}



}
