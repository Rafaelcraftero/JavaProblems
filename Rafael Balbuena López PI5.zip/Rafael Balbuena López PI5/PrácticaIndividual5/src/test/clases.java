package test;

public class clases {

	private grupos destino;
	
	private grupos fuente;
	
	public clases() {
		super();
		this.destino=grupos.of();
		this.fuente=grupos.of();
	}

	private clases(grupos fuente, grupos destino) {
		super();
		this.destino=fuente;
		this.fuente=destino;
	}

	private clases(grupos fuente, grupos destino, String[] formato) {
		super();
		this.destino=fuente;
		this.fuente=destino;
	}
	public double getP1() {
		return 1;
	}

	
	public static clases ofGrupos(grupos fuente, grupos destino) {
		return new clases(fuente, destino);
	}

	public static clases ofFormat(grupos fuente, grupos destino, String[] formato) {
		return new clases(fuente, destino, formato);
	}

	public static clases of() {
		return new clases();
	}

	public grupos getDestino() {
		return destino;
	}

	public void setDestino(grupos destino) {
		this.destino = destino;
	}

	public grupos getFuente() {
		return fuente;
	}

	public void setFuente(grupos fuente) {
		this.fuente = fuente;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((destino == null) ? 0 : destino.hashCode());
		result = prime * result + ((fuente == null) ? 0 : fuente.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		clases other = (clases) obj;
		if (destino == null) {
			if (other.destino != null)
				return false;
		} else if (!destino.equals(other.destino))
			return false;
		if (fuente == null) {
			if (other.fuente != null)
				return false;
		} else if (!fuente.equals(other.fuente))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "clases [destino=" + destino + ", fuente=" + fuente + "]";
	}
	
	
	
	
	

}
