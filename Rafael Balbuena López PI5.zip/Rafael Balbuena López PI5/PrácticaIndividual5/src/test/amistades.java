package test;

public class amistades {
	private static Double P1=(double) 1;
	private static int num=0;
	private persona PersonaA;
	private persona PersonaB;
	private int id;
	
	
	public static  amistades ofVertex(String personaA, String personaB) {
		return new amistades(personaA, personaB);
	}
	public static  amistades ofFormat(persona personaA, persona personaB, String[] Aux) {
		return new amistades(personaA, personaB);
	}
	public static amistades of() {
		return new amistades();
	}

	public static  amistades ofName(persona personaA, persona personaB) {
		return new amistades(personaA, personaB);
	}

	public static amistades create(String[] s) {
		return ofVertex(s[0],s[1]);
	}

	amistades(persona personaA, persona personaB) {
		super();
		this.PersonaA = personaA;
		this.PersonaB = personaB;
		this.id=num;
		num++;

	}
	
	amistades(persona personaA, persona personaB, String[] formato) {
		super();
		this.PersonaA = personaA;
		this.PersonaB = personaB;
		this.id=num;
		num++;

	}

	public amistades() {
		super();
		this.PersonaA = null;
		this.PersonaB = null;
		this.id=num;
		num++;

	}

	public persona getPersonaA() {
		return PersonaA;
	}
	public int getId() {
		return id;
	}
	public double getP1() {
		return P1;
	}

	public persona getPersonaB() {
		return PersonaB;
	}

	public amistades(String personaA, String personaB) {
		this.PersonaA=persona.ofName(personaA);
		this.PersonaB=persona.ofName(personaB);
		this.id=num;
		num++;

	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((PersonaA == null) ? 0 : PersonaA.hashCode());
		result = prime * result + ((PersonaB == null) ? 0 : PersonaB.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof amistades))
			return false;
		amistades other = (amistades) obj;
		if (PersonaA == null) {
			if (other.PersonaA != null)
				return false;
		} else if (!PersonaA.equals(other.PersonaA))
			return false;
		if (PersonaB == null) {
			if (other.PersonaB != null)
				return false;
		} else if (!PersonaB.equals(other.PersonaB))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return ""+ PersonaA + " " + PersonaB +"";
	}

}

