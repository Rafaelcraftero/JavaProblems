#include "ejercicio3.h"


long Sol3While(long a,int n){
	long res=1;
	int i=0;
	if(n!=0){
		if(n%2==0){
			while((n/2)>i){
				res=res*a;
				i++;
			}
			res=res*res;
		}else if (n%2==1){
			while((n/2)>i){
				res=res*a;
				i++;
			}
			res=res*res*a;
		}
	}
	return res;
}


void Sol3RecLinFin(long a,int n, long*res){
	if(n!=0){
		if(n%2==0){
			*res=Sol3RecLinFinAux(a,n, 0, *res);
			*res=*res**res;
			Sol3RecLinFin(a,0,res);
		}
		else if(n%2==1){
			*res=Sol3RecLinFinAux(a,n, 0, *res);
			*res=*res**res*a;
			Sol3RecLinFin(a,0,res);
		}

	}
}

long Sol3RecLinFinAux(long a,int n, int i, long res){

	if(n/2>i){
		res= Sol3RecLinFinAux(a,n, i+1, res*a);

	}

return res;
}
//

long Sol3RecLinNoFin(long a,int n){
	long res=0;
	res=Sol3RecLinNoFinAux(a,n, 0);
	if(n%2==0){
		res=res*res;
	}
	else if(n%2==1){
		res=res*res*a;
	}
	return res;
}

long Sol3RecLinNoFinAux(long a,int n, int i){
	long res=0;
	if(n!=0){
		if(!(n/2>i)){
			return 1;
		}else{
			res=a*Sol3RecLinNoFinAux(a,n,i+1);
		}
	}
	return res;
}
//


void testEjercicio3(){
	list lectura=list_of_string_of_file("ficheros/PI2Ej3DatosEntrada.txt");
	char * tokens[2];
	char cadena1[256];
	char cadena2[256];
	char buffer[1024]="", aux[1024]="";
	long valor=1;
	long*resRLF=&valor;
	int i=0, entero1=0,entero2=0;
	while(i<lectura.size){
		long valor=1;

		snprintf(aux, sizeof aux, "%s",list_get_string(&lectura,i,aux));
		split_text((char*)aux, ",", tokens);
		snprintf(cadena1, sizeof cadena1, "%s",tokens[0]);
		snprintf(cadena2, sizeof cadena2, "%s",tokens[1]);
		if(strlen(cadena1)!=0 && strlen(cadena2)!=0){

			entero1=int_parse_s((char*)cadena1);
			entero2=int_parse_s((char*)cadena2);
			Sol3RecLinFin((long)entero1,entero2, resRLF);
			snprintf(buffer, sizeof buffer, "%s%s\n1. iterativa (while): %ld\n2. Recursiva final: %ld\n3. Recursiva no final: %ld\n4. Funcional: No aplicable\n\n\n",
					&buffer,list_get_string(&lectura,i,aux),Sol3While((long)entero1,entero2), *resRLF,Sol3RecLinNoFin((long)entero1,entero2));
		}
		resRLF=&valor;
		i++;
	}

	printf("%s",buffer);
	solucionAFichero("ficheros/PI2Ej3Resultados.txt",buffer);


}

