#include <stdio.h>
#include <stdlib.h>

#include "types/list.h"

#include "types/math2.h"

#include "types/types.h"

#include "aFichero.h"
#ifndef EJERCICIOS_EJERCICIO2_H_
#define EJERCICIOS_EJERCICIO2_H_

//
char* esMultiploWhile(int, int);
void testEjercicio2();
void esMultiploRecLinFin(int, int, char*);
char* esMultiploRecLinFinnAux(int, int ,int, char*);
//

#endif /* EJERCICIOS_EJERCICIO2_H_ */
