#include "ejercicio1.h"

int sol1While(char*cadena1,char*cadena2){
	int res=-1,i=0;
	while(i<strlen(cadena1)){
		if(cadena1[i]!=cadena2[i]){
			res=i;
			break;
		}
		i++;
	}
	if(res==strlen(cadena1)){
		res=-1;

	}
	return res;
}
//

void sol1RecLinFin(char*cadena1,char*cadena2, int*res){
	if(*res==-1){
		*res=sol1RecLinFinAux(cadena1, cadena2, 0);

		sol1RecLinFin(cadena1,cadena2,res);
	}	if(*res==strlen(cadena1)){
		*res=-1;
	}

}
//

int sol1RecLinFinAux(char*cadena1,char*cadena2,int i){
	int res=i;
	if((i<strlen(cadena1) && cadena1[i]==cadena2[i])){
		res=sol1RecLinFinAux(cadena1, cadena2, i+1);
	}
	return res;

}


void testEjercicio1(){

	list lectura=list_of_string_of_file("ficheros/PI2Ej1DatosEntrada.txt");

	char * tokens[2];
	char cadena1[256];
	char cadena2[256];
	char buffer[1024]="", aux[1024];
	int valor=-1;
	int*resRLF=&valor;
	int i=0;

	while(i<lectura.size){
		int valor=-1;
		snprintf(aux, sizeof aux, "%s",list_get_string(&lectura,i,aux));
		split_text((char*)aux, "#", tokens);
		snprintf(cadena1, sizeof cadena1, "%s",tokens[0]);
		snprintf(cadena2, sizeof cadena2, "%s",tokens[1]);
		if(strlen(cadena1)!=0){
			sol1RecLinFin(cadena1,cadena2, resRLF);
			if(strlen(cadena1)!=strlen(cadena2)){
				snprintf(buffer, sizeof buffer, "%s%s\nNo tienen el mismo n�mero de caracteres\n\n\n",&buffer,list_get_string(&lectura,i,aux));

			}else if(*resRLF==-1){
				snprintf(buffer, sizeof buffer, "%s%s\nSon oraciones identicas\n\n\n",&buffer,list_get_string(&lectura,i,aux));

			}else{
				snprintf(buffer, sizeof buffer, "%s%s\n1. iterativa (while): %d\n2. Recursiva final: %d\n3. Funcional: No aplicable\n\n\n",&buffer,list_get_string(&lectura,i,aux),sol1While(cadena1,cadena2),*resRLF);

			}
				resRLF=&valor;
		}

		i++;
	}
	printf("%s",buffer);
	solucionAFichero("ficheros/PI2Ej1Resultados.txt",buffer);
}
