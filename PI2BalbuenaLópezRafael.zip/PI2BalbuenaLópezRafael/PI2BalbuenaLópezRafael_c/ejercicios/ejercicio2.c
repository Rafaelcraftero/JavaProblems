#include "ejercicio2.h"
//


char* esMultiploWhile(int a, int b){
	char*res=malloc(10);
	snprintf(res, sizeof res, "false");
	while(a!=0 && a>=b){
		a=a-b;
		if(a==0){
			snprintf(res, sizeof res, "true");
			break;
		}
		if(b>a){
			snprintf(res, sizeof res, "false");
			break;
		}
	}
	return res;
}
//


void esMultiploRecLinFin(int a, int b, char*res){
	if(strcmp(res,"")==0){
		res=esMultiploRecLinFinnAux(a, b, 0,res);
		esMultiploRecLinFin(a,b,res);
	}
}
//


char* esMultiploRecLinFinnAux(int a, int b,int i, char*res){
	if(a!=0 && a>=b){
		a=a-b;
		if(a==0){
			snprintf(res, sizeof res, "true");
			return res;
		}
		if(b>a){
			snprintf(res, sizeof res, "false");
			return res;
		}
		res=esMultiploRecLinFinnAux(a,b,i+1,res);
	}
	return res;

}
//


void testEjercicio2(){
	list lectura=list_of_string_of_file("ficheros/PI2Ej2DatosEntrada.txt");
	char * tokens[2];
	char cadena1[256];
	char cadena2[256];
	char buffer[1024]="", aux[1024];
	char valor[256]="";
	char*resRLF= valor;
	int i=0, entero1=0,entero2=0;
	while(i<lectura.size){
		snprintf(aux, sizeof aux, "%s",list_get_string(&lectura,i,aux));
		split_text((char*)aux, ",", tokens);
		snprintf(cadena1, sizeof cadena1, "%s",tokens[0]);
		snprintf(cadena2, sizeof cadena2, "%s",tokens[1]);
		if(strlen(cadena1)!=0 && strlen(cadena2)!=0){
			char valor[256]="";
			entero1=int_parse_s((char*)cadena1);
			entero2=int_parse_s((char*)cadena2);
			esMultiploRecLinFin(entero1,entero2, resRLF);
			snprintf(buffer, sizeof buffer, "%s%s\n1. iterativa (while): %s\n2. Recursiva final: %s\n3. Funcional: No aplicable\n\n\n",&buffer,list_get_string(&lectura,i,aux),esMultiploWhile(entero1,entero2),resRLF);
			resRLF=valor;
		}
		i++;
	}
	printf("%s",buffer);
	solucionAFichero("ficheros/PI2Ej2Resultados.txt",buffer);
}

