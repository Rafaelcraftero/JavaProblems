#include <stdio.h>
#include <stdlib.h>

#include "types/list.h"

#include "types/math2.h"

#include "types/types.h"
#include "ejemplos/ejemplos2.h"

#include "aFichero.h"

#ifndef EJERCICIOS_EJERCICIO1_H_
#define EJERCICIOS_EJERCICIO1_H_

//
void testEjercicio1();
int sol1While(char*, char*);
int sol1RecLinFinAux(char*,char*,int);
void sol1RecLinFin(char*,char*, int*);
//
#endif /* EJERCICIOS_EJERCICIO1_H_ */
