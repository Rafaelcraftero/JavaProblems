#include <stdio.h>
#include <stdlib.h>

#include "types/list.h"
#include "types/types.h"
#include "types/hash_table.h"

#include "aFichero.h"
#ifndef EJERCICIOS_EJERCICIO3_H_
#define EJERCICIOS_EJERCICIO3_H_

//
long Sol3While(long,int);
void testEjercicio3();
long Sol3RecLinFinAux(long,int, int, long);
void Sol3RecLinFin(long,int, long*);
long Sol3RecLinNoFinAux(long,int, int);
long Sol3RecLinNoFin(long,int);
//

#endif /* EJERCICIOS_EJERCICIO3_H_ */
