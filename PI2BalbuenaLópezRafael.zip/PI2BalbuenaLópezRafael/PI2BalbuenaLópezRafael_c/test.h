#include <stdio.h>
#include <stdlib.h>

#include "ejercicios/ejercicio1.h"
#include "ejercicios/ejercicio2.h"
#include "ejercicios/ejercicio3.h"

#ifndef TEST_H_
#define TEST_H_

#endif /* TEST_H_ */
