module PI2BalbuenaL�pezRafael {
	requires partecomun;
	requires datos_compartidos;
}