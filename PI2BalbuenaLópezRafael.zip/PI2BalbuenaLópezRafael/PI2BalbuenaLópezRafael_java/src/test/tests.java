package test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ejercicios.Ejercicio1;
import ejercicios.Ejercicio2;
import ejercicios.Ejercicio3;
import us.lsi.common.Files2;

public class tests {
	public static void main(String[] args) {
		//testEjercicio1();
		//testEjercicio2();
		testEjercicio3();
	}
	
	
	public static void testEjercicio1() {
		String file="ficheros/PI2Ej1DatosEntrada.txt";
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		int i=0, resWhile=0, resRec=0, resFuncional=0;
		String res="";
		String[] StrAux= {};
		while(i<lectura.size()) {
			StrAux=lectura.get(i).split("#");
			if(!(StrAux[0].isEmpty() || StrAux[0].isEmpty())) {
			resWhile=Ejercicio1.sol1While(StrAux[0], StrAux[1]);
			resRec=Ejercicio1.sol1RecLinFin(StrAux[0], StrAux[1], -1);
			resFuncional=Ejercicio1.sol1Funcional(StrAux[0], StrAux[1]);
			res=res + lectura.get(i)+"\n1. iterativa (while): "+resWhile +"\n2. Recursiva final: "+resRec+"\n3. Funcional: "+resFuncional+"\n\n\n";
			}
			i++;
		
		}
		System.out.println(res);
		Files2.toFile(res,"ficheros/PI2Ej1Resultados.txt");

	}
	

	public static void testEjercicio2() {
		String file="ficheros/PI2Ej2DatosEntrada.txt";
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		int i=0;
		String[] StrAux= {};
		String resWhile="",resRec="",resFuncional="", res="";
		while(i<lectura.size()) {
			StrAux=lectura.get(i).split(",");
			resWhile=Ejercicio2.esMultiploWhile(Integer.parseInt(StrAux[0].trim()),
					Integer.parseInt(StrAux[1].trim()));
			resRec=Ejercicio2.esMultiploRecLinFin(Integer.parseInt(StrAux[0].trim()),
					Integer.parseInt(StrAux[1].trim()),"");
			if(	Ejercicio2.esMultiploFuncional(Integer.parseInt(StrAux[0].trim()),
					Integer.parseInt(StrAux[1].trim()))==1) {
				resFuncional="true";
			}else {
				resFuncional="false";			
			}
			res=res + lectura.get(i)+"\n1. iterativa (while): "+resWhile +"\n2. Recursiva final: "+resRec+"\n3. Funcional: "+resFuncional+"\n\n\n";
			i++;
		}
		System.out.println(res);
		Files2.toFile(res,"ficheros/PI2Ej2Resultados.txt");
}

	
	public static void testEjercicio3() {
		
		String file="ficheros/PI2Ej3DatosEntrada.txt";
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		int i=0;
		String[] StrAux= {};
		long resWhile=0,resRec=0, resFuncional=0, resRecNoFinal=0;
		String res="";
		while(i<lectura.size()) {
			StrAux=lectura.get(i).split(",");
			resWhile=Ejercicio3.Sol3While((long) Integer.parseInt(StrAux[0].trim()), Integer.parseInt(StrAux[1].trim()));
			resRec=Ejercicio3.Sol3RecLinFin((long) Integer.parseInt(StrAux[0].trim()), Integer.parseInt(StrAux[1].trim()), 1);
			resRecNoFinal=Ejercicio3.Sol3RecLinNoFin((long) Integer.parseInt(StrAux[0].trim()), Integer.parseInt(StrAux[1].trim()));
			resFuncional=Ejercicio3.sol3Funcional((long) Integer.parseInt(StrAux[0].trim()), Integer.parseInt(StrAux[1].trim()));
			res=res + lectura.get(i)+"\n1. iterativa (while): "+resWhile +"\n2. Recursiva final: "+resRec+"\n3. Recursiva no final: "+resRecNoFinal+"\n4. Funcional: "+resFuncional+"\n\n\n";
			i++;
		}
		System.out.println(res);
		Files2.toFile(res,"ficheros/PI2Ej3Resultados.txt");
	}
	
	

	
	
}
