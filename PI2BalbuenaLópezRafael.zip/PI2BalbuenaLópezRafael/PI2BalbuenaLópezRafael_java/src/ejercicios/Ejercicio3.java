package ejercicios;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Ejercicio3 {

	public static long Sol3While(long a,int n){
		long res=1;
		int i=0;
		if(n!=0){
			if(n%2==0){
				while((n/2)>i){
					res=res*a;
					i++;
				}
				res=res*res;
			}else if (n%2==1){
				while((n/2)>i){
					res=res*a;
					i++;
				}
				res=res*res*a;
			}
		}
		return res;
	}


	public static long Sol3RecLinFin(long a,int n, long res){
		if(n!=0){
			if(n%2==0){
				res=Sol3RecLinFinAux(a,n, 0, res);
				res=res*res;
				Sol3RecLinFin(a,0,res);
			}
			else if(n%2==1){
				res=Sol3RecLinFinAux(a,n, 0, res);
				res=res*res*a;
				Sol3RecLinFin(a,0,res);
			}
		}
		return res;
	}

	public static long Sol3RecLinFinAux(long a,int n, int i, long res){

		if(n/2>i){
			res= Sol3RecLinFinAux(a,n, i+1, res*a);

		}

	return res;
	}
	//

	public static long Sol3RecLinNoFin(long a,int n){
		long res=0;
		res=Sol3RecLinNoFinAux(a,n, 0);
		if(n%2==0){
			res=res*res;
		}
		else if(n%2==1){
			res=res*res*a;
		}
		return res;
	}

	public static long Sol3RecLinNoFinAux(long a,int n, int i){
		long res=0;
		if(n!=0){
			if(!(n/2>i)){
				return 1;
			}else{
				res=a*Sol3RecLinNoFinAux(a,n,i+1);
			}
		}
		return res;
	}
	public static long sol3Funcional(long a,int n){
	
		long valor=IntStream.iterate(0, x->x<n/2, x->x+1).map(x->{long res=1;res=res*a;return (int) res;}).reduce((acum, num)->acum*num).getAsInt();
		if(n%2==0){
			valor=valor*valor;
			return valor;
		}else if (n%2==1){
			valor=valor*valor*a;
			return valor;
		}
	return valor;
	}
}
