package ejercicios;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import us.lsi.geometria.Punto2D;
import us.lsi.math.Math2;

public class Ejercicio1 {
	
	public static int sol1While(String cadena1,String cadena2){
		int res=-1,i=0;
		while(i<cadena1.length()){
			if(cadena1.charAt(i)!=cadena2.charAt(i)){
				res=i;
				break;
			}
			i++;
		}
		if(res==cadena1.length()){
			res=-1;

		}
		return res;
	}
	//

	public static int sol1RecLinFin(String cadena1,String cadena2, int res){
		if(res==-1){
			res=sol1RecLinFinAux(cadena1, cadena2, 0);

			sol1RecLinFin(cadena1,cadena2,res);
		}	if(res==cadena1.length()){
			res=-1;
		}
		return res;

	}
	//

	public static int sol1RecLinFinAux(String cadena1,String cadena2,int i){
		int res=i;
		if((i<cadena1.length() && cadena1.charAt(i)==cadena2.charAt(i))){
			res=sol1RecLinFinAux(cadena1, cadena2, i+1);
		}
		return res;

	}
	
	public static int sol1Funcional(String cadena1,String cadena2){
		return (int)IntStream.range(0, cadena1.length()-1).takeWhile(i->Objects.equals(cadena1.charAt(i), cadena2.charAt(i))).count();

	}
	
	
	
	
	
}
