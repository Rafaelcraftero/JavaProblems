package ejercicios;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import us.lsi.common.Tuple;
import us.lsi.common.Tuple2;

public class Ejercicio2 {
	
	public static String esMultiploWhile(int a, int b){
		String res="false";
		while(a!=0 && a>=b){
			a=a-b;
			if(a==0){
				res="true";
				break;
			}
			if(b>a){
				res="false";
				break;
			}
		}
		return res;
	}
	//
 

	public static String esMultiploRecLinFin(int a, int b, String res){
		if(res.isEmpty()){
			res=esMultiploRecLinFinnAux(a, b, 0,res);
			esMultiploRecLinFin(a,b,res);
		}
		return res;
	}
	//


	public static String esMultiploRecLinFinnAux(int a, int b, int i, String res){
		if(a!=0 && a>=b){
			a=a-b;
			if(a==0){
				res="true";
				return res;
			}
			if(b>a){
				res="false";
				return res;
			}
			res=esMultiploRecLinFinnAux(a,b,i+1,res);
		}
		return res;

	}
	public static int esMultiploFuncional(int a, int b){
		 return (int) Stream.iterate(new int[]{a,b},n->n[0]>=0 ,n->new int[]{n[0]-n[1],n[1]}).filter(n->n[0]==0).count();
	}	
	
}
