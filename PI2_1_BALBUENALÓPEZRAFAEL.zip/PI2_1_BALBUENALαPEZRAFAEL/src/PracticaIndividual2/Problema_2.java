package PracticaIndividual2;
//
import java.util.ArrayList;
import java.util.List;
import us.lsi.tiposrecursivos.BinaryTree;
//
public class Problema_2 implements PracticaIndividual{
//
	public Problema_2() {
		return;
	}
	
//
//	Problema 2
//
	
	public List<Integer> mergeSort(List<Integer> list) {
	    if (list.size() < 2) {
	      return list;
	    }
	    int mitad = list.size()/2;
	    return aux(mergeSort(list.subList(0, mitad)),mergeSort(list.subList(mitad, list.size())));
	  }
//
	
	  private static List<Integer> aux(List<Integer> left, List<Integer> right) {
	    int IndiceIzq = 0;
	    int IndiceDer = 0;
	    List<Integer> aux = new ArrayList<Integer>();

	    while (IndiceIzq < left.size() && IndiceDer < right.size()) {
	      if (left.get(IndiceIzq) < right.get(IndiceDer)) {
	        aux.add(left.get(IndiceIzq++));
	      } else {
	        aux.add(right.get(IndiceDer++));
	      }
	    }
	    aux.addAll(left.subList(IndiceIzq, left.size()));
	    aux.addAll(right.subList(IndiceDer, right.size()));
	    return aux;
	  }
//
	  
	@Override
	public <E> Boolean SonEquilibrados(BinaryTree<E> T) {
		return null;
	}

}

