package PracticaIndividual2;
//
import PracticaIndividual2.Problema_1;
import PracticaIndividual2.Problema_2;
import us.lsi.tiposrecursivos.BinaryTree;
import java.util.ArrayList;
import PracticaIndividual2.PracticaIndividual;
//
public class testPracticaIndividual{
//
	public static void main(String[] args) {
		testProblema1();
		testProblema2();
	}
	
//
//	Problema 1
//
	
	public static void testProblema1() {
		//BinaryTree<Integer> t0= BinaryTree.empty();
		BinaryTree<Integer> t1= BinaryTree.leaf(1);
		BinaryTree<Integer> t2= BinaryTree.leaf(2);
		BinaryTree<Integer> t3= BinaryTree.leaf(3);
		BinaryTree<Integer> t4= BinaryTree.leaf(4);
		BinaryTree<Integer> t5= BinaryTree.binary(5,t1, t2);
		BinaryTree<Integer> t6= BinaryTree.binary(6, t3, t4);
		BinaryTree<Integer> equilibrado= BinaryTree.binary(7, t6, t5);
		//BinaryTree<Integer> desEquilibrado= BinaryTree.binary(8, equilibrado, t0);		
		//
		PracticaIndividual aux = new Problema_1();
		System.out.println("Estan equilibrados: "+ aux.SonEquilibrados(equilibrado));
		
		
	}
	
//
//	Problema 2
//
	
	public static void testProblema2() {
		ArrayList<Integer> res= new ArrayList<Integer>();
		res.add(45);res.add(17);res.add(23);res.add(67);res.add(21);
		//
		PracticaIndividual aux = new Problema_2();
		System.out.println("lista original:  " + res );
		System.out.println("Nueva lista ordenada: " + aux.mergeSort(res));
	}
//
	
}