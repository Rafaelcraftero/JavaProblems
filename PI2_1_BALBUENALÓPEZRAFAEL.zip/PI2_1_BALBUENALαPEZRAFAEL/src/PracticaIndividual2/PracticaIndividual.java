package PracticaIndividual2;
//
import java.util.List;
import us.lsi.tiposrecursivos.BinaryTree;
//
public interface PracticaIndividual {
	
//
//		Problema 1
//
	
	<E> Boolean SonEquilibrados(BinaryTree<E> T);
	
//
//		Problema 2
//
	
	List<Integer> mergeSort(List<Integer> list);
}
