package PracticaIndividual2;
//
import java.util.List;
import us.lsi.tiposrecursivos.BinaryTree;
//
public class Problema_1 implements PracticaIndividual {
//
	public Problema_1() {
		return;
	}
	
//
//	Problema 1
//
	
	public <E> Boolean SonEquilibrados(BinaryTree<E> T) {
		Boolean res=false;
		Integer Aux=0;
		switch(T.getType()) {
		case Empty:
			res=true;
			break;
		case Leaf:
			res=true;
			break;
		case Binary:
			res=false;
			Aux=Math.abs(T.getRight().getHeight()-T.getLeft().getHeight());
			if(Aux==1 || Aux==0) {
			res=SonEquilibrados(T.getRight()) && SonEquilibrados(T.getLeft());
			}
			break;
		}
		return res;
	}
//
	
	@Override
	public List<Integer> mergeSort(List<Integer> list) {
		return null;
	}

}
