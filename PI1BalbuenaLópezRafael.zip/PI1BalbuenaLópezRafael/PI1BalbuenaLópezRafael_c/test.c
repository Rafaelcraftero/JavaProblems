#include "test.h"

int main(){
	//testEjercicio1();
	//testEjercicio2();
	testEjercicio3();
	return 0;
}
