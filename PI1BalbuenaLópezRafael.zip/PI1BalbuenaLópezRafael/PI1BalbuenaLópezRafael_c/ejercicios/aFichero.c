#include "aFichero.h"

void solucionAFichero(char* fileEnd, char* cadena){
	FILE* f;
	f=fopen(fileEnd,"w");
	fprintf(f,"%s\n",cadena);
	fclose(f);

}
