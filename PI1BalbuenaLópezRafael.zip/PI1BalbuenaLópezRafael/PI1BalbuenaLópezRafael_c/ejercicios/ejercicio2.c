#include "ejercicio2.h"
char* solucion2(int limit) {

	char buf[5000];
	int i=2;
	char* lim="L�mite ";
	snprintf(buf, sizeof buf, "%s%d:\n", lim,limit);
	if(i<=limit) {
		while(i<=limit) {
			int primo2=i*i;
			snprintf(buf, sizeof buf, "%s%d\n", buf,primo2);
			i=siguiente_primo((long) i);
		}
		snprintf(buf, sizeof(buf), "%s\n========================================\n", buf);
	}
	char*res=buf;
	return res;
}

list leeEjercicio2(char* file){

		list lectura=list_of_string_of_file(file);
		char mem[4000];
		list res=list_empty(int_type);

		int i=0;
		char* Aux="";
		char* subString="";
		while(i<lectura.size) {
			Aux=list_get_string(&lectura,i, mem);
			subString = strtok(Aux,"Limite: ");
			int a=int_parse_s(subString);
			list_add(&res, &a);
			i++;
		}
		return res;
	}

void testEjercicio2() {
	char* fileInit="ficheros/PI1Ej2DatosEntrada.txt";
	char* fileEnd="ficheros/PI1Ej2Resultados.txt";
	int i=0;
	string sRes=string_empty();
	list Aux=list_empty(int_type);
	Aux=leeEjercicio2(fileInit);
	while(i<Aux.size){
		int intAux=*(int*) list_get(&Aux,i);
		string_add_pchar(&sRes,solucion2(intAux));
		i++;

	}
	solucionAFichero(fileEnd,sRes.data);
}

