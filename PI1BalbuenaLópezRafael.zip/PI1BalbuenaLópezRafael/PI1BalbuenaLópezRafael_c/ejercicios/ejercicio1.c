#include "ejercicio1.h"

list solucion1(list listas) {
	int i=0, i2=0;
	list lista = list_empty(int_type);
	while(i<listas.size){
		i2=0;
		list Aux = *(list*)list_get(&listas,i);
		while(i2<Aux.size){
			long Nprimo =*(long*) list_get(&Aux,i2);
			if(es_primo(Nprimo)){
				list_add (&lista, list_get(&Aux,i2));

			}
			i2++;
		}
		i++;
	}

	return lista;
}

void testEjercicio1(){
	char mem[500];
	char* fileInit="ficheros/PI1Ej1DatosEntrada.txt";
	char* fileEnd="ficheros/PI1Ej1Resultados.txt";
	list lista=solucion1(file_to_list_of_list(fileInit));
	solucionAFichero (fileEnd, list_tostring(&lista,mem));
}
