#include <stdio.h>
#include <stdlib.h>

#include "types/list.h"

#include "types/math2.h"

#include "types/types.h"

#include "aFichero.h"
#ifndef EJERCICIOS_EJERCICIO2_H_
#define EJERCICIOS_EJERCICIO2_H_

char* solucion2(int);
list leeEjercicio3(char*);
void testEjercicio2();

#endif /* EJERCICIOS_EJERCICIO2_H_ */
