#include <stdio.h>
#include <stdlib.h>

#ifndef EJERCICIOS_AFICHERO_H_
#define EJERCICIOS_AFICHERO_H_

void solucionAFichero(char* fileEnd, char* cadena);


#endif /* EJERCICIOS_AFICHERO_H_ */
