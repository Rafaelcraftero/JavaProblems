#include "ejercicio3.h"

hash_table solucion3(list ls){
	hash_table res= hash_table_empty(int_type, double_type);
	int i=0;
	double primercuadrante = 0.0;
	double segundocuadrante = 0.0;
	double tercercuadrante = 0.0;
	double cuartocuadrante = 0.0;

	while(i<ls.size) {
		punto p =*(punto*)list_get(&ls,i);
		Cuadrante cuadrante=punto_cuadrante(&p);
		if(cuadrante==PRIMERO){
			primercuadrante+=p.x;

		}else if(cuadrante==SEGUNDO){
			segundocuadrante+=p.x;

		}else if(cuadrante==TERCERO){

			tercercuadrante+=p.x;
		}else if(cuadrante==CUARTO){

			cuartocuadrante+=p.x;
		}

		i++;
	}
	Cuadrante primero= PRIMERO;
	Cuadrante segundo= SEGUNDO;
	Cuadrante tercero= TERCERO;
	Cuadrante cuarto= CUARTO;
	hash_table_put(&res, &primero, &primercuadrante);
	hash_table_put(&res, &segundo, &segundocuadrante);
	hash_table_put(&res, &tercero, &tercercuadrante);
	hash_table_put(&res, &cuarto, &cuartocuadrante);

	return res;
}

list leeEjercicio3(char*file ){
	char mem[256];
	list lectura=list_of_string_of_file(file);
	list res=list_empty(punto_type);
    int i=0;

	while(i<lectura.size){

		char* strAux=list_get_string(&lectura,i, mem);
		punto p=punto_parse_s(strAux);;
		list ls = list_of(&p,1,punto_type);
		list_add (&res, list_get(&ls,0));

		i++;
	}
	return res;
}

void testEjercicio3(){
	char res[512];
	char* fileInit="ficheros/PI1Ej3DatosEntrada.txt";
	char* fileEnd="ficheros/PI1Ej3Resultados.txt";

	list lectura=leeEjercicio3(fileInit);
	hash_table solucion=solucion3(lectura);

	int d1p=0;
	int d2p=1;
	int d3p=2;
	int d4p=3;

	double d1= *(double*) hash_table_get(&solucion, &d1p);
	double d2= *(double*) hash_table_get(&solucion, &d2p);
	double d3= *(double*) hash_table_get(&solucion, &d3p);
	double d4= *(double*) hash_table_get(&solucion, &d4p);

	snprintf(res, sizeof res, "{PRIMER_CUADRANTE=%lf, SEGUNDO_CUADRANTE=%lf,"
			"TERCER_CUADRANTE=%lf,CUARTO_CUADRANTE=%lf}",d1,d2,d3,d4);
	solucionAFichero(fileEnd,res);
}
