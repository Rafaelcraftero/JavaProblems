module pI1BalbuenaL�pezRafael {
	requires partecomun;
	requires datos_compartidos;
}