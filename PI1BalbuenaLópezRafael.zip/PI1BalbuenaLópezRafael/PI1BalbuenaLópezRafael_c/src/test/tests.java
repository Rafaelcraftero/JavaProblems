package test;

 import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ejercicios.Ejercicio1;
import ejercicios.Ejercicio2;
import ejercicios.Ejercicio3;
import us.lsi.common.Files2;
import us.lsi.geometria.Punto2D;

public class tests {

	public static void main(String[] args) {
		//testEjercicio1();
		//testEjercicio2();
		//testEjercicio3();
	}
	public static void testEjercicio1() {
		Files2.toFile(Ejercicio1.solucion1(leeEjercicio1("ficheros/PI1Ej1DatosEntrada.txt")).toString(),
				"ficheros/PI1Ej1Resultados.txt");
		
		
	}
	
	public static void testEjercicio2() {
		int i=0;
		String res="";
		List<Integer> Aux= new ArrayList<>(leeEjercicio2("ficheros/PI1Ej2DatosEntrada.txt"));
		while(i<leeEjercicio2("ficheros/PI1Ej2DatosEntrada.txt").size()){
			res=res+Ejercicio2.solucion2(Aux.get(i))+"========================================\n";
			i++;
		}
		Files2.toFile(res,"ficheros/PI1Ej2Resultados.txt");
	}
	
	public static void testEjercicio3() {
		Files2.toFile(Ejercicio3.solucion3(leeEjercicio3("ficheros/PI1Ej3DatosEntrada.txt")).toString(),
				"ficheros/PI1Ej3Resultados.txt");
	}	
	

	public static List<List<Integer>> leeEjercicio1(String file){
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		List<List<Integer>> res= new ArrayList<>();
		List<Integer> IntAux=new ArrayList<>();
		int i=0, i2;
		String[] StrAux= {};
		while(i<lectura.size()) {
			IntAux.clear();
			i2=0;
			StrAux=lectura.get(i).split(",");
			while(i2<StrAux.length) {
				IntAux.add(Integer.parseInt(StrAux[i2].trim()));
				i2++;
			}
			res.add(IntAux.stream().collect(Collectors.toList()));
			i++;
		}
		return res;
	}
	
	
	public static List<Integer> leeEjercicio2(String file){
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		List<Integer> res=new ArrayList<>();
		int i=0, i2;
		String[] StrAux= {};
		while(i<lectura.size()) {
			i2=0;
			StrAux=lectura.get(i).split(":");
			while(i2<StrAux.length) {
				if(!StrAux[i2].contains("Limite")) {
					res.add(Integer.parseInt(StrAux[i2].trim()));
				}
				i2++;
			}
			i++;
		}
		return res;
	}
	
	public static List<Punto2D> leeEjercicio3(String file){
		List<String> lectura=new ArrayList<String>(Files2.linesFromFile(file));
		List<Punto2D> res=new ArrayList<>();
		int i=0;
		String[] StrAux= {};
		while(i<lectura.size()) {
			StrAux=lectura.get(i).substring(1, lectura.get(i).length()-1).split(",");
			res.add(Punto2D.create( Double.parseDouble(StrAux[0].trim()),
					Double.parseDouble(StrAux[1].trim())));
			i++;

		}
		return res;
	}
	
}

