package ejercicios;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import us.lsi.math.Math2;

public class Ejercicio2 {
	public static String ejemploN(Integer limit){
		return Stream.iterate(2,x->x<=limit,x->Math2.siguientePrimo(x))
		.map(x->x*x)
		.map(x->x.toString())
		.collect(Collectors.joining("\n"));
		}
	
	public static String solucion2(Integer limit) {
		int i=2;
		String res="L�mite "+limit+":\n";
		if(i<=limit) {
			while(i<=limit) {
				res=res+(i*i)+"\n";
				i=Math2.siguientePrimo(i);
			}
		}
		return res+"\n";
	}
	
	
	
	
	
	
}
