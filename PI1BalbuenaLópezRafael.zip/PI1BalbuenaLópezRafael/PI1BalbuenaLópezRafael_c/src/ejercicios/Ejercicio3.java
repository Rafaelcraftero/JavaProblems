package ejercicios;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import us.lsi.geometria.Punto2D;

public class Ejercicio3 {
	
	public static Map<Punto2D.Cuadrante,Double> ejemploU(List<Punto2D> l){
		return l.stream()
		.collect(Collectors.groupingBy(Punto2D::getCuadrante,
		Collectors.<Punto2D,Double>reducing(0.,x->x.getX(),(x,y)->x+y)));
		}
	
	
	public static Map<Punto2D.Cuadrante,Double> solucion3(List<Punto2D> l){
		Map<Punto2D.Cuadrante,Double> res= new HashMap<>();
		int i=0; 
		Double primercuadrante = 0.0;
		Double segundocuadrante = 0.0;
		Double tercercuadrante = 0.0;
		Double cuartocuadrante = 0.0;
		while(i<l.size()) {
			Punto2D.Cuadrante cuadrante=l.get(i).getCuadrante();
			
			if(cuadrante==Punto2D.Cuadrante.PRIMER_CUADRANTE) {
				primercuadrante+=l.get(i).getX();
			}else if(cuadrante==Punto2D.Cuadrante.SEGUNDO_CUADRANTE) {
				segundocuadrante+=l.get(i).getX();					
			}else if(cuadrante==Punto2D.Cuadrante.TERCER_CUADRANTE) {
				tercercuadrante+=l.get(i).getX();							
			}else if(cuadrante==Punto2D.Cuadrante.CUARTO_CUADRANTE) {
				cuartocuadrante+=l.get(i).getX();				
			}

			i++;
		}
		res.put(Punto2D.Cuadrante.PRIMER_CUADRANTE, primercuadrante);
		res.put(Punto2D.Cuadrante.SEGUNDO_CUADRANTE, segundocuadrante);
		res.put(Punto2D.Cuadrante.TERCER_CUADRANTE, tercercuadrante);
		res.put(Punto2D.Cuadrante.CUARTO_CUADRANTE, cuartocuadrante);
		return res;
	}
	
	
	
	
}
