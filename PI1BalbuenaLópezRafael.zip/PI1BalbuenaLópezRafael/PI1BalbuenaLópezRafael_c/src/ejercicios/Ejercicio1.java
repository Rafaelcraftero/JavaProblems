package ejercicios;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import us.lsi.math.Math2;

public class Ejercicio1 {
	
	public static List<Integer> ejemploI (List<List<Integer>> listas) {
		return listas
		.stream()
		.flatMap(lista -> lista.stream())
		.filter(e -> (Math2.esPrimo(e)))
		.collect(Collectors.toList());
		}
	
	public static List<Integer> solucion1 (List<List<Integer>> listas) {
		int i=0 , i2=0;
		List<Integer> lista=new ArrayList<>();
		while(i<listas.size()) {
			i2=0;
			while(i2<listas.get(i).size()) {
					if(Math2.esPrimo(listas.get(i).get(i2))) {
					lista.add(listas.get(i).get(i2));
				}
				i2++;
			}
			i++;
		}
		return lista;
		
	}
	
	
	
}
