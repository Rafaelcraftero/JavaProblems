package PI3;

import java.util.List;

public class auxTest {
	public List<ciudadesVertex> a1;
	public double a2;
		public List<ciudadesVertex> getA1() {
			return a1;
		}
		public void setA1(List<ciudadesVertex> a1) {
			this.a1 = a1;
		}
		public double getA2() {
			return a2;
		}
		public void setA2(double a2) {
			this.a2 = a2;
		}
}
