package PI3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class SolucionBarriosAG {

	public static SolucionBarriosAG create() {
		return new SolucionBarriosAG();
	}

	private Map<String, Integer> m;	///////////////////////////////


	private SolucionBarriosAG() {
		super();
		this.m = new HashMap<String ,Integer>();
	}

	public void add(String ob, int nu) {
		Integer n = nu;
		if(m.containsKey(ob)) n = nu+m.get(ob);			
		this.m.put(ob, n);	
	}

	public void remove(String ob, int nu) {
		this.m.put(ob, Math.max(m.get(ob)-nu,0));	
	}

	public SolucionBarriosAG copy() {
		return new SolucionBarriosAG();
	}

	public Set<String> elements(){
		return m.keySet();
	}

	public Map<String, Integer> getM() {
		return m;
	}

	public void setM(Map<String, Integer> m) {
		this.m = m;
	}

	@Override
	public String toString() {
		return "Solucion=" + m + "";
	}

	private SolucionBarriosAG(Map<String, Integer> m) {
		super();
		this.m = m;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((m == null) ? 0 : m.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SolucionBarriosAG other = (SolucionBarriosAG) obj;
		if (m == null) {
			if (other.m != null)
				return false;
		} else if (!m.equals(other.m))
			return false;
		return true;
	}
	public List<String> getIds() {
		return m.keySet().stream().collect(Collectors.toList());
	}

	public Integer getNumero() {
		return m.keySet().stream().mapToInt(x->m.get(x)).sum();
	}

	public void add(String id, Integer nu) {
		this.m.put(id, nu);
	}
}
