package PI3;


public class ciudadesVertex {

	private String Ciudad;

	
	public int compare(ciudadesVertex o1, ciudadesVertex o2) {
		return o1.getCiudad().compareTo(o2.getCiudad());
	}
	
	
	public static  ciudadesVertex create(String s) {
		return new ciudadesVertex(s);
	}

	public static ciudadesVertex create(String[] formato) {
		return new ciudadesVertex(formato);
	}

	public String getCiudad() {
		return Ciudad;
	}

	public void setCiudad(String ciudad) {
		Ciudad = ciudad;
	}
	public String toString() {
		return Ciudad ;
	}

	private ciudadesVertex(String ciudad) {
		super();
		Ciudad = ciudad;
	}
	public ciudadesVertex(String[] formato) {
		super();
		this.Ciudad = formato[0];
	}	

	public static ciudadesVertex create() {
		return new ciudadesVertex("");
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Ciudad == null) ? 0 : Ciudad.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ciudadesVertex other = (ciudadesVertex) obj;
		if (Ciudad == null) {
			if (other.Ciudad != null)
				return false;
		} else if (!Ciudad.equals(other.Ciudad))
			return false;
		return true;
	}

}

