package PI3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import us.lsi.ag.ValuesInRangeChromosome;
import us.lsi.ag.ValuesInRangeProblemAG;
import us.lsi.ag.agchromosomes.AlgoritmoAG;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;
import us.lsi.ag.agstopping.StoppingConditionFactory;
import us.lsi.common.Streams2;
import us.lsi.lpsolve.solution.AlgoritmoPLI;

/*
 * PI3.1. Estaciones de bomberos: una ciudad est� considerando
 *  la ubicaci�n de sus estaciones de bomberos. La ciudad se compone de n barrios.
 *  Cada barrio es vecino de otros barrios. Una estaci�n de bomberos se puede colocar
 *  en cualquier barrio bi y es capaz de gestionar los incendios tanto de dicho barrio bi 
 *  como de cualquier barrio vecino de bi. El objetivo es minimizar el n�mero de estaciones de bomberos. 
 * 
 *  	Como ejemplo concreto, teniendo un total de 6 barrios b0...b5, y siendo los grupos
 *  	de vecinos de cada barrio {b0, b1}, {b0, b1, b5}, {b2, b3}, {b2, b3, b4}, {b3, b4, b5}, {b1, b4, b5},
 *  	la soluci�n �ptima ser�a establecer dos estaciones de bomberos, en los barrios b1 y b3.
 */



public class Ejercicio_3_1{

	public static List<barriosVecinos> barrio=null;


	public static void main(String[] args) {
		//solucionLpSolveTest();
		solucionAGTest();
		

	}
	
	public static void solucionAGTest() {
		AlgoritmoAG.ELITISM_RATE= 0.30;
		AlgoritmoAG.CROSSOVER_RATE=0.8;
		AlgoritmoAG.MUTATION_RATE=0.7;
		AlgoritmoAG.POPULATION_SIZE=100;
		StoppingConditionFactory.NUM_GENERATIONS = 6000;
		StoppingConditionFactory.SOLUTIONS_NUMBER_MIN = 1;
		StoppingConditionFactory.FITNESS_MIN = 623;
		StoppingConditionFactory.stoppingConditionType = 
		StoppingConditionFactory.StoppingConditionType.SolutionsNumber;
		ValuesInRangeProblemAG<Integer, SolucionBarriosAG> p= new barriosAG("ficheros/barrios.txt");
		
		AlgoritmoAG<ValuesInRangeChromosome<Integer>> a= AlgoritmoAG.create(ChromosomeType.Binary, p);
		a.ejecuta();
		ValuesInRangeChromosome<Integer> pp= a.getBestChromosome();
		SolucionBarriosAG  m =p.getSolucion(pp);
		System.out.println(m);
		
	}



	public static void solucionLpSolveTest() {
		List<barriosVecinos> Barrios=cargaDatos("ficheros/barrios.txt");
		String lpSolveFile= getConstraint(Barrios, 1);
		System.out.println(lpSolveFile);
		AlgoritmoPLI sol = (AlgoritmoPLI) AlgoritmoPLI.getSolution(lpSolveFile);
		for(int i=0;i<sol.getNumVar();i++){
			System.out.println(sol.getName(i)+ " = " + sol.getSolution(i));
		}
		System.out.println("Funcion objetivo: " + sol.getGoal());		
	}

	public static String getConstraint(List<barriosVecinos> Barrios,  Integer t) {
		String res="";
		Set<String> restriccionesAux= new HashSet<String>();
		for(int i=0;i<Barrios.size();i++){
			restriccionesAux.addAll(Barrios.get(i).getVecinos());
		}
		List<String> restricciones= new ArrayList<String>();
		restricciones.addAll(restriccionesAux);
		res=res+IntStream.range(0,Barrios.size()).boxed().map(i->Barrios.get(i).getId()).collect(Collectors.joining("+", "min: ", ";\n")); 
		res=res+restricciones.stream().collect(Collectors.joining("="+t+";\n", "", "="+t+";\n")); 
		res=res+IntStream.range(0,Barrios.size()).boxed().map(i->Barrios.get(i).getId()).collect(Collectors.joining(",", "bin " , ";\n"));  
		return res;
	}
	public static List<barriosVecinos> cargaDatosRestricciones(String linea){
		barriosVecinos bar2=null;
		List<barriosVecinos> bar= new ArrayList<barriosVecinos>();	
		String idAux=linea.replaceAll(",", " ");
		idAux=idAux.replaceAll("\\+", " "); 								
		List<String> idAux2=Arrays.asList(idAux.split(" ")); 					
		Set<String> idAux3=	 idAux2.stream().collect(Collectors.toSet());
		List<String> Ids = idAux3.stream().collect(Collectors.toList()); 
		for(int i=0;i<Ids.size();i++) {
			bar2=barriosVecinos.create(linea,Ids.get(i).toString());
			bar.add(bar2);
		}
		return bar;
	}

	public static List<barriosVecinos> cargaDatos(String file){	
		return cargaDatosRestricciones(Streams2.fromFile(file)
				.collect(Collectors.toList()).toString().replace("[", "").replace("]", "").replace(" ", ""));
	}
}





