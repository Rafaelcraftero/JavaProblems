package PI3;

public class ciudadesEdge {

	private ciudadesVertex ciudadA;
	private ciudadesVertex ciudadB;
	private double Coste;
	private double duracion;

	public static  ciudadesEdge create(String ciudadA, String ciudadB, String[] s) {
		return new ciudadesEdge(ciudadA, ciudadB, Double.parseDouble(s[2]),Double.parseDouble(s[3]));
	}
	public static ciudadesEdge create() {
		return new ciudadesEdge();
	}

	public static  ciudadesEdge create(ciudadesVertex ciudadA, ciudadesVertex ciudadB, String[] s) {
		return new ciudadesEdge(ciudadA, ciudadB, Double.parseDouble(s[2]),Double.parseDouble(s[3]));
	}

	public static ciudadesEdge create(String[] s) {
		return create(s[0],s[1], Double.parseDouble(s[3]),  Double.parseDouble(s[4]));
	}

	ciudadesEdge(ciudadesVertex ciudadA, ciudadesVertex ciudadB, double duracion, double Coste) {
		super();
		this.ciudadA = ciudadA;
		this.ciudadB = ciudadB;
		this.Coste = Coste;
		this.duracion = duracion;
	}


	public ciudadesEdge() {
		super();
		this.ciudadA = null;
		this.ciudadB = null;
		this.Coste = 0.0;
		this.duracion = 0.0;
	}



	public ciudadesVertex getciudadA() {
		return ciudadA;
	}



	public ciudadesVertex getciudadB() {
		return ciudadB;
	}



	public double getCoste() {
		return this.Coste;
	}



	public double getDuracion() {
		return this.duracion;
	}

	public ciudadesEdge(String ciudadA, String ciudadB, double duracion, double Coste) {
		this.ciudadA=ciudadesVertex.create(ciudadA);
		this.ciudadB=ciudadesVertex.create(ciudadB);
		this.Coste=Coste;
		this.duracion=duracion;

	}

	private ciudadesEdge(ciudadesVertex ciudadA, ciudadesVertex ciudadB, double duracion) {

		this.ciudadA=ciudadA;
		this.ciudadB=ciudadB;
		this.Coste=0.0;
		this.duracion=duracion;
	}


	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ciudadA == null) ? 0 : ciudadA.hashCode());
		long temp;
		temp = Double.doubleToLongBits(Coste);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((ciudadB == null) ? 0 : ciudadB.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ciudadesEdge))
			return false;
		ciudadesEdge other = (ciudadesEdge) obj;
		if (ciudadA == null) {
			if (other.ciudadA != null)
				return false;
		} else if (!ciudadA.equals(other.ciudadA))
			return false;
		if (Double.doubleToLongBits(Coste) != Double
				.doubleToLongBits(other.Coste))
			return false;
		if (ciudadB == null) {
			if (other.ciudadB != null)
				return false;
		} else if (!ciudadB.equals(other.ciudadB))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ciudades [ciudadA=" + ciudadA + ", ciudadB=" + ciudadB + ", Coste="
				+ Coste + ", duracion=" + duracion + "]";
	}


	public static ciudadesEdge create(String ciudadA, String ciudadB, double duracion,double Coste) {
		return new ciudadesEdge(ciudadA, ciudadB, Coste, duracion);
	}
	public static ciudadesEdge create(ciudadesVertex ciudadA, ciudadesVertex ciudadB, double duracion) {
		return new ciudadesEdge(ciudadA,ciudadB, duracion);
	}



}

