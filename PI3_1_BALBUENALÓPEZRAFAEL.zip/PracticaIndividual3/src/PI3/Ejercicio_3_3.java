package PI3;

import java.util.*;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.ShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.tour.HeldKarpTSP;

import org.jgrapht.graph.SimpleWeightedGraph;

import us.lsi.graphs.GraphsReader;

/* � PI3.3. Un grupo de amigos quiere realizar un viaje recorriendo una serie de ciudades que entre todos han seleccionado.
 *  Cada trayecto (de un lugar a otro) supone un tiempo y un coste. Suponiendo lo anterior, d� respuesta a las siguientes preguntas: 
 *
 *		o �Cu�l es la ruta m�s econ�mica para ir de una ciudad o a d? �y la m�s corta en tiempo? 
 *		o �Es posible un viaje que pase por todas las ciudades (una sola vez) partiendo de una ciudad origen y volviendo a ella misma minimizando el tiempo? 
 *		o Dado un subconjunto de ciudades a visitar, encontrar una ruta partiendo de una ciudad origen y volviendo a ella que pase por dichas ciudades, 
 *		que intente minimizar el coste.*/

public class Ejercicio_3_3 {

	public static void main2(String[] args) {
		costeTest();
		duracionTest();
		idaYVueltaMinTest();
		caminoMinConSubConjuntoTest();
	}

	public static void costeTest() {
		String file="P3-Grafo.txt";
		String A="Lugar0";
		String B="Lugar9";
		var res=coste( file,  A,  B);
		System.out.println("De "+A+" a "+B+" con menor coste ("+res.getWeight()+" �):"+res.getVertexList());
	}

	public static void duracionTest() {
		String file="P3-Grafo.txt";
		String A="Lugar0";
		String B="Lugar9";
		var res=duracion( file,  A,  B);
		System.out.println("De "+A+" a "+B+" con menor tiempo ("+res.getWeight()+" mins.)"+res.getVertexList());
	}
	public static void idaYVueltaMinTest() {
		String file="P3-Grafo.txt";
		var res=idaYVueltaMin(file);
		System.out.println("Ida-Vuelta en menos tiempo ("+res.a2+" mins.) pasando por todos los lugares: \n"+res.a1);					

	}

	public static void caminoMinConSubConjuntoTest() {
		String file="P3-Grafo.txt";
		String A="Lugar0";
		ciudadesVertex[] m= {ciudadesVertex.create("Lugar7"), ciudadesVertex.create("Lugar5"),ciudadesVertex.create("Lugar4")};
		//ciudadesVertex[] m= {ciudadesVertex.create("Lugar7")};
		var res=caminoMinConSubConjunto(file, A, Arrays.asList(m).stream().collect(Collectors.toList()));
		System.out.println("Ida-vuelta m�s econ�mica "+"("+res.getA2()+"�) pasando por "+Arrays.asList(m).stream().collect(Collectors.toList())+":\n"+res.getA1());
	}

	public static GraphPath<ciudadesVertex,ciudadesEdge> coste(String file, String A, String B) {
		SimpleWeightedGraph<ciudadesVertex,ciudadesEdge> graph =  
				GraphsReader.newGraph(file,ciudadesVertex::create,
						ciudadesEdge::create,
						()->new SimpleWeightedGraph<ciudadesVertex,ciudadesEdge>(ciudadesVertex::create,ciudadesEdge::create),
						ciudadesEdge::getCoste);
		ShortestPathAlgorithm<ciudadesVertex,ciudadesEdge> a = new DijkstraShortestPath<ciudadesVertex,ciudadesEdge>(graph);
		ciudadesVertex ciudadA = ciudadesVertex.create(A);
		ciudadesVertex ciudadB = ciudadesVertex.create(B);
		GraphPath<ciudadesVertex,ciudadesEdge> gp =  a.getPath(ciudadA,ciudadB);
		return gp;
	}

	public static GraphPath<ciudadesVertex,ciudadesEdge> duracion(String file, String A, String B) {
		SimpleWeightedGraph<ciudadesVertex,ciudadesEdge> graph =  
				GraphsReader.newGraph(file,ciudadesVertex::create,
						ciudadesEdge::create,
						()->new SimpleWeightedGraph<ciudadesVertex,ciudadesEdge>(ciudadesVertex::create,ciudadesEdge::create),
						ciudadesEdge::getDuracion);	
		ShortestPathAlgorithm<ciudadesVertex,ciudadesEdge> a = new DijkstraShortestPath<ciudadesVertex,ciudadesEdge>(graph);
		ciudadesVertex ciudadA = ciudadesVertex.create(A);
		ciudadesVertex ciudadB = ciudadesVertex.create(B);
		GraphPath<ciudadesVertex,ciudadesEdge> gp =  a.getPath(ciudadA,ciudadB);
		return gp;
	}

	public static auxTest idaYVueltaMin(String file) {	
		SimpleWeightedGraph<ciudadesVertex,ciudadesEdge> graph =  
				GraphsReader.newGraph(file,ciudadesVertex::create,
						ciudadesEdge::create,
						()->new SimpleWeightedGraph<ciudadesVertex,ciudadesEdge>(ciudadesVertex::create,ciudadesEdge::create),
						ciudadesEdge::getDuracion);
		List<ciudadesVertex> r3 = new HeldKarpTSP<ciudadesVertex, ciudadesEdge>().getTour(graph).getVertexList();	
		Double i=new HeldKarpTSP<ciudadesVertex, ciudadesEdge>().getTour(graph).getWeight();
		auxTest o=new auxTest();
		o.setA1(r3);
		o.setA2(i);
		return o;
	}

	public static auxTest caminoMinConSubConjunto(String file, String A, List<ciudadesVertex> cv) {
		List<ciudadesVertex> m=cv.stream().collect(Collectors.toList());
		List<ciudadesVertex> res=new ArrayList<ciudadesVertex>();
		m.add(0, ciudadesVertex.create(A));
		m.add(m.size(), ciudadesVertex.create(A));
		Double resCount=0.0;
		var gp=	coste( file,m.get(0).toString(),m.get(1).toString());
		resCount=gp.getWeight();
		res.addAll(gp.getVertexList().stream().collect(Collectors.toList()));
		res.remove(res.size()-1);
		for(int i=1;i<m.size()-1;i++) {
			gp=coste( file,  m.get(i).toString(),  m.get(i+1).toString());
			resCount=resCount+gp.getWeight();
			if(i==m.size()-2) {
				res.addAll(gp.getVertexList().stream().collect(Collectors.toList()));
				break;
			}
			else {
				res.addAll(gp.getVertexList().stream().collect(Collectors.toList()));
				res.remove(res.size()-1);
			}
		}
		auxTest o=new auxTest();
		o.setA1(res);
		o.setA2(resCount);
		return o;
	}
}


