package PI3;

import java.util.*;
import java.util.stream.Collectors;

public class barriosVecinos{

	private List<String> vecinos;
	private String id;

	@Override
	public String toString() {
		return "barriosVecinos [vecinos=" + vecinos + ", id=" + id + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((vecinos == null) ? 0 : vecinos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		barriosVecinos other = (barriosVecinos) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (vecinos == null) {
			if (other.vecinos != null)
				return false;
		} else if (!vecinos.equals(other.vecinos))
			return false;
		return true;
	}

	public List<String> getVecinos() {
		return vecinos;
	}

	public void setVecinos(List<String> vecinos) {
		this.vecinos = vecinos;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static barriosVecinos create(String restricciones, String id) {
		List<String> res= Arrays.asList(restricciones.split(","));
		return new barriosVecinos(res.stream().filter(x->x.toString().contains(id)).collect(Collectors.toList()), id);
	}

	public static barriosVecinos create(String id) {
		return new barriosVecinos(id);
	}
	
	
	private barriosVecinos(List<String> vecinos, String id) {
		super();
		this.vecinos = vecinos;
		this.id = id;
	}

	public barriosVecinos(String id) {
		this.id=id;
		this.vecinos=null;
	}

}

















