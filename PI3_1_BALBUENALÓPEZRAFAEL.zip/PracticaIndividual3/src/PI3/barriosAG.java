package PI3;

import java.util.List;

import us.lsi.ag.ValuesInRangeChromosome;
import us.lsi.ag.ValuesInRangeProblemAG;

public class barriosAG implements ValuesInRangeProblemAG<Integer,SolucionBarriosAG>{
	
	public static List<barriosVecinos> barrio=null;
	
	public barriosAG(String fichero) {
		barrio=Ejercicio_3_1.cargaDatos(fichero);
		System.out.println(barrio);
	}	
	
	public SolucionBarriosAG getSolucion(ValuesInRangeChromosome<Integer> cr) {  
		SolucionBarriosAG res= SolucionBarriosAG.create();
		List<Integer> ls=cr.decode();
		for(int i=0;i<this.getVariableNumber();i++) {
			res.add(barrio.get(i).getId(), ls.get(i));
		
		}
		return res;	
	}
	
	
	private Double nRestricciones;
	private Double dif;
	private Double fitness = null;
	private void calcula(List<Integer> ls){
		Double peso=0.;
		dif=0.;
		for(int i=0;i<ls.size();i++) {
			peso=peso+ls.get(i)*barrio.get(i).getVecinos().size();
		}
		nRestricciones=(double) barrio.size();
		if(nRestricciones<=peso) {
			dif=peso-nRestricciones;
		}
	}
	
	public Double fitnessFunction(ValuesInRangeChromosome<Integer> c) {
		List<Integer> ls = c.decode();
		calcula(ls);
		fitness=dif;
		return -fitness;
	}
	
	public Integer getVariableNumber() {
		return barrio.size();
	}

	public Integer getMax(Integer i) {
		return barrio.size()-1;
	}

	public Integer getMin(Integer i) {
		return 0;
	}




}
